var suitehelp = {};
suitehelp.contexts={"bw.fileplugin_bw.fileplugin.fileserializer":"GUID-4EA4954A-0887-4AC8-8AEE-1944F4C9A8F1.html","bw.fileplugin_bw.fileplugin.fileparser":"GUID-3C0041CE-5632-41AE-9D04-A3288982D48B.html","filepluginresource":"GUID-21B4CFAC-DECD-456F-B361-6AEBB9AD90E7.html"};
// Check for a context-sensitive link and redirect if present (and valid)
suitehelp.checkContext = function () {
    "use strict";

    var context = suitehelp.contexts[suitehelp.getQueryString("context")],
        adjustedQS =  window.location.search.substring(1).replace(/context=[^&]+&|(&|^)context=[^&]+/, "");
    if (context) {
        if (adjustedQS) {
       
            document.location =  document.getElementsByTagName("head")[0].getAttribute("data-approot") + context + "?" + adjustedQS;
        } else {
            document.location =  document.getElementsByTagName("head")[0].getAttribute("data-approot") + context;
        }
    }

};

// Lookup a query string variable
suitehelp.getQueryString = function (key) {
    "use strict";

    if (!suitehelp.queryString) {
        suitehelp.queryString = {};
        var query = window.location.search.substring(1),
            vars = query.split("&"),
            i,
            pair;
        for (i = 0; i < vars.length; i += 1) {
            pair = vars[i].split("=");
            suitehelp.queryString[pair[0]] = unescape(pair[1]);
        }
    }

    return suitehelp.queryString[key];
};

suitehelp.checkContext();