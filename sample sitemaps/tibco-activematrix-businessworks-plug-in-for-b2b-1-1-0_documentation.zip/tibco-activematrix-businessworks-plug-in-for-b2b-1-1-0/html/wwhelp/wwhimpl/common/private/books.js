// Copyright (c) 2001-2003 Quadralay Corporation.  All rights reserved.
//

function  WWHBookGroups_Books(ParamTop)
{
  var  BookGrouping1;


  BookGrouping1 = ParamTop.fAddGrouping("TIBCO ActiveMatrix BusinessWorks Plug-in for B2B", null, null, null);
    BookGrouping1.fAddDirectory("TIB_bwpluginedi_1.1.0_installation", null, null, null, null);
    BookGrouping1.fAddDirectory("tib_bwpluginedi_user_guide", null, null, null, null);
}

function  WWHBookGroups_ShowBooks()
{
  return true;
}

function  WWHBookGroups_ExpandAllAtTop()
{
  return false;
}
