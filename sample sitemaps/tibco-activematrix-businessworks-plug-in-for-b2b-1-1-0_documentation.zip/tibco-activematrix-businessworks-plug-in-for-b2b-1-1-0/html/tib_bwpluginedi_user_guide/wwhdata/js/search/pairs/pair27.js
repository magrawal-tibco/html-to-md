function FileData_Pairs(x)
{
x.t("example","demonstrate");
x.t("available","tib_translator_home");
x.t("files","written");
x.t("files","taken");
x.t("files","including");
x.t("shown","figure");
x.t("wish","test");
x.t("demodata","directory");
x.t("instructions","sample");
x.t("variables","details");
x.t("variables","defining");
x.t("variables","point");
x.t("variables","select");
x.t("variables","inputfolder");
x.t("source","guidelines");
x.t("dialog","locate");
x.t("sample","projects");
x.t("sample","project");
x.t("open","bwb2b-sample");
x.t("open","project");
x.t("open","existing");
x.t("left","side");
x.t("bwb2b-sample","project");
x.t("bwb2b-sample","global");
x.t("start","tibco");
x.t("details","edit");
x.t("indicates","input");
x.t("indicates","output");
x.t("file","tib_translator_home");
x.t("complete","following");
x.t("check","global");
x.t("test","project");
x.t("test","process");
x.t("specified","map");
x.t("definition","wish");
x.t("guidelines","specified");
x.t("guidelines","target");
x.t("guidelines","schemas");
x.t("follows","similar");
x.t("tasks","task");
x.t("edit","global");
x.t("directories","project");
x.t("map","files");
x.t("map","file");
x.t("target","guidelines");
x.t("input","files");
x.t("input","data");
x.t("defining","global");
x.t("designer","click");
x.t("point","correct");
x.t("button","open");
x.t("button","test");
x.t("button","task");
x.t("button","click");
x.t("select","process");
x.t("schemas","map");
x.t("setup","translatorwithcallback_sample");
x.t("outputfolder","value");
x.t("outputfolder","global");
x.t("written","shown");
x.t("side","project");
x.t("software","chapter");
x.t("chapter","using");
x.t("user-defined","global");
x.t("inputfolder","outputfolder");
x.t("inputfolder","global");
x.t("section","takes");
x.t("properly","check");
x.t("directory","directory");
x.t("directory","tibco");
x.t("directory","defined");
x.t("works","properly");
x.t("task","open");
x.t("task","test");
x.t("steps","open");
x.t("steps","ensure");
x.t("tibco","designer");
x.t("tibco","software");
x.t("database","directory");
x.t("projects","setting");
x.t("click","open");
x.t("click","button");
x.t("click","tester");
x.t("ensure","process");
x.t("variable","indicates");
x.t("variable","guidelines");
x.t("project","example");
x.t("project","available");
x.t("project","dialog");
x.t("project","start");
x.t("project","complete");
x.t("project","follows");
x.t("project","button");
x.t("project","setup");
x.t("project","section");
x.t("project","tibco");
x.t("project","click");
x.t("project","panel");
x.t("project","setting");
x.t("project","contains");
x.t("bwb2b","sample");
x.t("existing","project");
x.t("taken","value");
x.t("translatorwithcallback_sample","project");
x.t("similar","instructions");
x.t("value","outputfolder");
x.t("value","inputfolder");
x.t("figure","bwb2b-sample");
x.t("figure","figure");
x.t("process","bwb2b-sample");
x.t("process","definition");
x.t("process","input");
x.t("process","works");
x.t("takes","bwb2b");
x.t("panel","click");
x.t("output","files");
x.t("correct","directories");
x.t("data","used");
x.t("defined","inputfolder");
x.t("locate","sample");
x.t("global","variables");
x.t("global","variable");
x.t("two","user-defined");
x.t("following","tasks");
x.t("following","steps");
x.t("used","sample");
x.t("setting","sample");
x.t("using","sample");
x.t("demonstrate","sample");
x.t("tab","left");
x.t("tib_translator_home","demodata");
x.t("tib_translator_home","database");
x.t("including","source");
x.t("contains","two");
x.t("tester","tab");
}
