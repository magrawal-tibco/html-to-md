function FileData_Pairs(x)
{
x.t("easy","integration");
x.t("scalable","extensible");
x.t("integration","projects");
x.t("integration","platform");
x.t("business","processes");
x.t("user","interface");
x.t("interface","tibco");
x.t("getting","started");
x.t("engine","executes");
x.t("includes","graphical");
x.t("menu","option");
x.t("testing","process");
x.t("overview","overview");
x.t("overview","tibco");
x.t("graphical","user");
x.t("deploying","project");
x.t("test","integration");
x.t("entails","following");
x.t("creating","project");
x.t("creating","process");
x.t("session","entails");
x.t("allows","develop");
x.t("started","overview");
x.t("develop","test");
x.t("accessed","help");
x.t("defining","business");
x.t("designer","defining");
x.t("designer","documentation");
x.t("designer","help");
x.t("designer","typical");
x.t("software","chapter");
x.t("chapter","getting");
x.t("extensible","easy");
x.t("processes","engine");
x.t("processes","detailed");
x.t("processes","tibco");
x.t("detailed","information");
x.t("steps","creating");
x.t("tibco","designer");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("option","tibco");
x.t("projects","tibco");
x.t("documentation","accessed");
x.t("project","creating");
x.t("project","tibco");
x.t("configuration","session");
x.t("activematrix","businessworks");
x.t("process","testing");
x.t("process","deploying");
x.t("process","adding");
x.t("platform","allows");
x.t("help","menu");
x.t("help","designer");
x.t("information","configure");
x.t("configure","processes");
x.t("typical","configuration");
x.t("activities","process");
x.t("executes","processes");
x.t("following","steps");
x.t("businessworks","scalable");
x.t("businessworks","includes");
x.t("adding","activities");
}
