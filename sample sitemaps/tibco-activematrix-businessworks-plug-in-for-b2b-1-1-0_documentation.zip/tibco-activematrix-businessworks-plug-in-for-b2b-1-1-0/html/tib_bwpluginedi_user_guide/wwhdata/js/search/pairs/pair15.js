function FileData_Pairs(x)
{
x.t("example","rendezvous");
x.t("shown","palette");
x.t("create","transitions");
x.t("bar","visible");
x.t("rendezvous","activities");
x.t("getting","started");
x.t("start","end");
x.t("palettes","process");
x.t("palettes","activities");
x.t("add","activity");
x.t("add","activities");
x.t("menu","bar");
x.t("creating","process");
x.t("previously","created");
x.t("transitions","activities");
x.t("perform","following");
x.t("started","adding");
x.t("appears","design");
x.t("select","palettes");
x.t("activity","process");
x.t("design","panel");
x.t("drag","activities");
x.t("software","chapter");
x.t("chapter","getting");
x.t("steps","click");
x.t("end","activities");
x.t("tibco","software");
x.t("click","process");
x.t("configuration","information");
x.t("b2b","menu");
x.t("b2b","palette");
x.t("process","example");
x.t("process","start");
x.t("process","add");
x.t("process","previously");
x.t("process","perform");
x.t("process","tibco");
x.t("process","configuration");
x.t("process","adding");
x.t("panel","add");
x.t("panel","select");
x.t("panel","drag");
x.t("panel","configure");
x.t("panel","expand");
x.t("configure","activity");
x.t("information","b2b");
x.t("expand","b2b");
x.t("activities","palettes");
x.t("activities","appears");
x.t("activities","design");
x.t("activities","b2b");
x.t("activities","process");
x.t("created","creating");
x.t("following","steps");
x.t("adding","activities");
x.t("visible","create");
x.t("palette","shown");
x.t("palette","tibco");
x.t("palette","panel");
x.t("palette","palette");
}
