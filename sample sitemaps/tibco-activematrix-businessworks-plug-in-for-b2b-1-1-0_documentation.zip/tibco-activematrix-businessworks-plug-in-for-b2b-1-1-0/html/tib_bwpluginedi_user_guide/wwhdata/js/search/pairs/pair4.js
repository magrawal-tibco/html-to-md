function FileData_Pairs(x)
{
x.t("needs","tibco");
x.t("related","documentation");
x.t("foresight","instream");
x.t("foresight","translator");
x.t("provided","tibco");
x.t("customer","wants");
x.t("designed","plug-in");
x.t("instream","tibco");
x.t("preface","preface");
x.t("preface","tibco");
x.t("address","needs");
x.t("plug-in","b2b");
x.t("plug-in","integrated");
x.t("functions","provided");
x.t("connecting","tibco");
x.t("user-friendly","topics");
x.t("software","preface");
x.t("tibco","foresight");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("tibco","businessworks");
x.t("tibco","resources");
x.t("translator","user-friendly");
x.t("documentation","typographical");
x.t("activematrix","businessworks");
x.t("b2b","designed");
x.t("topics","related");
x.t("typographical","conventions");
x.t("wants","functions");
x.t("businessworks","customer");
x.t("businessworks","address");
x.t("businessworks","plug-in");
x.t("conventions","connecting");
x.t("integrated","tibco");
x.t("resources","tibco");
}
