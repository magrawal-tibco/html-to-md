function FileData_Pairs(x)
{
x.t("example","0x7e");
x.t("example","100");
x.t("example","selecting");
x.t("example","read");
x.t("example","integer");
x.t("example","126");
x.t("example","5010-837i_deidentify.xml");
x.t("0x7e","0x2a");
x.t("extensions","select");
x.t("supports","following");
x.t("indicator","future");
x.t("flattoflat","operation");
x.t("provide","correct");
x.t("exist","sure");
x.t("files","input_encoding");
x.t("files","file");
x.t("files","database");
x.t("files","already");
x.t("files","appropriate");
x.t("files","note");
x.t("0x2a","0x27");
x.t("0x2a","0x3a");
x.t("editoedi","flattoflat");
x.t("full","path");
x.t("every","translation");
x.t("lists","exceptions");
x.t("table","shows");
x.t("table","translated");
x.t("table","translator");
x.t("table","callbackbuffer");
x.t("description","description");
x.t("description","output_file");
x.t("description","dialog");
x.t("description","short");
x.t("description","name");
x.t("description","activity");
x.t("description","map_filename");
x.t("0x2b","0x3a");
x.t("refer","create");
x.t("create","una");
x.t("describes","data");
x.t("sending","content");
x.t("output_file","output");
x.t("callback","check");
x.t("callback","resource");
x.t("callback","shareresource");
x.t("callback","checkbox");
x.t("callback","function");
x.t("callback","buffer");
x.t("callback","resources");
x.t("source","guidelines");
x.t("source","guideline");
x.t("apply","current");
x.t("0x2e","0x3f");
x.t("current","activity");
x.t("shows","file");
x.t("field","loaded");
x.t("field","msg_content");
x.t("field","appears");
x.t("field","512");
x.t("field","global");
x.t("field","following");
x.t("field","used");
x.t("dialog","input");
x.t("dialog","select");
x.t("dialog","usable");
x.t("uses","correct");
x.t("mode","large");
x.t("mode","changed");
x.t("mode","store");
x.t("mode","selected");
x.t("mode","specifies");
x.t("mode","memory");
x.t("mode","configuration");
x.t("mode","note");
x.t("mode","run");
x.t("look","una=y");
x.t("errors","translator");
x.t("change","input");
x.t("type","example");
x.t("type","table");
x.t("type","description");
x.t("type","drop-down");
x.t("xmltoedi","item");
x.t("open","select");
x.t("input_encoding","string");
x.t("pdf","document");
x.t("input_file","string");
x.t("utf-16","iso8859-1");
x.t("formats","(source)");
x.t("formats","value");
x.t("formats","character");
x.t("formats","translation");
x.t("multiple","separator");
x.t("listed","dialog");
x.t("default","input");
x.t("default","output");
x.t("default","utf-8");
x.t("element","separator");
x.t("engine","generate");
x.t("translate","positional");
x.t("details","return");
x.t("thrown","activity");
x.t("thrown","indicating");
x.t("fstranslatorexception","occurs");
x.t("document","details");
x.t("document","recommended");
x.t("document","tibco");
x.t("document","output");
x.t("size","callback");
x.t("file","example");
x.t("file","extensions");
x.t("file","mode");
x.t("file","formats");
x.t("file","need");
x.t("file","flat");
x.t("file","accordingly");
x.t("file","input");
x.t("file","msg_content");
x.t("file","return_code");
x.t("file","activity");
x.t("file","cannot");
x.t("file","xml");
x.t("file","memory");
x.t("file","translated");
x.t("file","configuration");
x.t("file","send");
x.t("file","output");
x.t("file","note");
x.t("file","edi");
x.t("file","content");
x.t("short","description");
x.t("list","allows");
x.t("list","edi");
x.t("indicates","create");
x.t("need","add");
x.t("need","check");
x.t("need","sure");
x.t("need","specify");
x.t("add","description");
x.t("add","map");
x.t("recommends","select");
x.t("group","field");
x.t("normally","efficient");
x.t("check","callback");
x.t("check","checkbox");
x.t("check","correct");
x.t("flat","files");
x.t("flat","file");
x.t("large","document");
x.t("large","documents");
x.t("recommended","value");
x.t("sure","move");
x.t("sure","value");
x.t("sure","read");
x.t("fails","tibco");
x.t("specified","field");
x.t("specified","map");
x.t("operation","type");
x.t("operation","types");
x.t("name","file");
x.t("name","name");
x.t("name","map");
x.t("name","activity");
x.t("name","output");
x.t("definition","description");
x.t("stored","files");
x.t("stored","two");
x.t("guidelines","target");
x.t("guidelines","schemas");
x.t("path","name");
x.t("wrong","encoding");
x.t("ran","successfully");
x.t("changed","file");
x.t("follows","table");
x.t("codes","encoding");
x.t("accordingly","operation");
x.t("bytes","larger");
x.t("bytes","used");
x.t("component","element");
x.t("component","data");
x.t("avoid","error");
x.t("provides","translation");
x.t("(target)","edi");
x.t("0x27","note");
x.t("loaded","previous");
x.t("memory-based","string");
x.t("allows","specify");
x.t("map","file");
x.t("selection","input");
x.t("fields","table");
x.t("fields","field");
x.t("fields","input");
x.t("fields","output");
x.t("target","file");
x.t("target","guidelines");
x.t("target","define");
x.t("target","edifact");
x.t("target","guideline");
x.t("segment","callback");
x.t("segment","indicates");
x.t("segment","target");
x.t("segment","terminator");
x.t("string","field");
x.t("string","specifies");
x.t("string","(optional)");
x.t("iso8859-1","utf-8");
x.t("input","mode");
x.t("input","default");
x.t("input","file");
x.t("input","fields");
x.t("input","input");
x.t("input","activity");
x.t("input","data");
x.t("input","translation");
x.t("input","item");
x.t("input","encoding");
x.t("contain","improper");
x.t("resource","dialog");
x.t("resource","click");
x.t("store","large");
x.t("selected","input");
x.t("selected","output");
x.t("msg_content","field");
x.t("msg_content","string");
x.t("msg_content","output");
x.t("supported","translate");
x.t("supported","translator");
x.t("supported","separators");
x.t("documents","stored");
x.t("delimiters","refer");
x.t("delimiters","x12");
x.t("una=y","0x2b");
x.t("return_code","string");
x.t("error","thrown");
x.t("error","error");
x.t("error","output");
x.t("checkbox","enable");
x.t("checkbox","used");
x.t("shareresource","field");
x.t("occurs","translation");
x.t("button","open");
x.t("button","add");
x.t("options","file");
x.t("connecting","large");
x.t("select","editoedi");
x.t("select","apply");
x.t("select","file");
x.t("select","resource");
x.t("minimum","value");
x.t("appears","file");
x.t("appears","check");
x.t("appears","target");
x.t("appears","memory");
x.t("schemas","mapping");
x.t("means","map");
x.t("means","transaction");
x.t("activity","supports");
x.t("activity","table");
x.t("activity","uses");
x.t("activity","need");
x.t("activity","follows");
x.t("activity","provides");
x.t("activity","input");
x.t("activity","twice");
x.t("activity","memory");
x.t("activity","click");
x.t("activity","process");
x.t("activity","read");
x.t("activity","output");
x.t("activity","encoding");
x.t("terminator","element");
x.t("terminator","may");
x.t("cause","fstranslatorexception");
x.t("cause","translation");
x.t("function","callback");
x.t("function","takes");
x.t("indicating","output");
x.t("software","chapter");
x.t("chapter","b2b");
x.t("specifies","full");
x.t("specifies","name");
x.t("specifies","input");
x.t("specifies","return");
x.t("specifies","output");
x.t("specifies","content");
x.t("specifies","encoding");
x.t("define","value");
x.t("may","look");
x.t("cannot","opened");
x.t("move","output");
x.t("(bytes)","size");
x.t("edifact","indicates");
x.t("edifact","data");
x.t("twice","using");
x.t("format","table");
x.t("format","supported");
x.t("format","translates");
x.t("types","supported");
x.t("types","utf-8");
x.t("xml","flat");
x.t("xml","xml");
x.t("xml","edi");
x.t("release","indicator");
x.t("directory","translator");
x.t("map_filename","string");
x.t("positional","flat");
x.t("notification","release");
x.t("una=y/n","delimiters");
x.t("enable","callback");
x.t("code","example");
x.t("groups","otherwise");
x.t("0x3a","0x2e");
x.t("0x3a","0x5e");
x.t("folder","input_file");
x.t("return","codes");
x.t("return","code");
x.t("tibco","recommends");
x.t("tibco","software");
x.t("memory","mode");
x.t("memory","file");
x.t("memory","normally");
x.t("memory","memory");
x.t("memory","output");
x.t("memory","based");
x.t("database","folder");
x.t("output_directory","string");
x.t("previous","activity");
x.t("matches","input");
x.t("100","means");
x.t("successfully","158");
x.t("translator","callback");
x.t("translator","pdf");
x.t("translator","input");
x.t("translator","activity");
x.t("translator","tibco");
x.t("translator","translator");
x.t("translator","configuration");
x.t("translator","output");
x.t("translator","exceptions");
x.t("translated","field");
x.t("translated","file");
x.t("translated","output_directory");
x.t("(source)","(target)");
x.t("click","button");
x.t("158","means");
x.t("callbackbuffer","(bytes)");
x.t("(optional)","field");
x.t("(optional)","specifies");
x.t("configuration","fields");
x.t("configuration","configuration");
x.t("configuration","panel");
x.t("configuration","tab");
x.t("usable","translator");
x.t("value","field");
x.t("value","multiple");
x.t("value","msg_content");
x.t("value","matches");
x.t("value","separator");
x.t("0x3f","0x2a");
x.t("b2b","palette");
x.t("drop-down","list");
x.t("selecting","xmltoedi");
x.t("send","file");
x.t("already","exist");
x.t("process","example");
x.t("process","definition");
x.t("process","translator");
x.t("generate","exception");
x.t("exception","cause");
x.t("exception","undesired");
x.t("takes","data");
x.t("separators","component");
x.t("separators","segment");
x.t("separators","delimiters");
x.t("panel","need");
x.t("panel","input");
x.t("panel","specifies");
x.t("read","file");
x.t("output","files");
x.t("output","mode");
x.t("output","file");
x.t("output","memory-based");
x.t("output","fields");
x.t("output","contain");
x.t("output","error");
x.t("output","activity");
x.t("output","directory");
x.t("output","output");
x.t("output","location");
x.t("output","data");
x.t("output","file-based");
x.t("output","tab");
x.t("output","encoding");
x.t("output","item");
x.t("larger","document");
x.t("location","every");
x.t("location","error");
x.t("data","type");
x.t("data","element");
x.t("data","file");
x.t("data","stored");
x.t("data","wrong");
x.t("data","supported");
x.t("data","format");
x.t("data","translator");
x.t("data","separators");
x.t("data","hex");
x.t("data","translation");
x.t("correct","input");
x.t("correct","encoding");
x.t("future","segment");
x.t("appropriate","location");
x.t("512","bytes");
x.t("una","segment");
x.t("locate","translator");
x.t("global","var");
x.t("efficient","connecting");
x.t("character","example");
x.t("two","options");
x.t("note","provide");
x.t("note","source");
x.t("note","change");
x.t("note","file");
x.t("note","minimum");
x.t("note","una=y/n");
x.t("otherwise","output");
x.t("integer","example");
x.t("0x5e","edifact");
x.t("transaction","ran");
x.t("repetition","separator");
x.t("based","input");
x.t("opened","translator");
x.t("order","specified");
x.t("mapping","files");
x.t("utf-8","utf-16");
x.t("utf-8","default");
x.t("utf-8","encoding");
x.t("file-based","string");
x.t("translates","data");
x.t("following","formats");
x.t("following","fields");
x.t("following","input");
x.t("following","output");
x.t("used","memory");
x.t("used","translator");
x.t("used","locate");
x.t("separator","group");
x.t("separator","component");
x.t("separator","groups");
x.t("separator","data");
x.t("separator","repetition");
x.t("separator","order");
x.t("separator","decimal");
x.t("126","hex");
x.t("hex","example");
x.t("hex","format");
x.t("5010-837i_deidentify.xml","source");
x.t("run","process");
x.t("edi","file");
x.t("edi","flat");
x.t("edi","target");
x.t("edi","xml");
x.t("edi","data");
x.t("edi","edi");
x.t("improper","separators");
x.t("guideline","describes");
x.t("using","input");
x.t("translation","engine");
x.t("translation","fails");
x.t("translation","specified");
x.t("translation","operation");
x.t("translation","avoid");
x.t("translation","target");
x.t("translation","function");
x.t("translation","process");
x.t("tab","lists");
x.t("tab","contains");
x.t("decimal","notification");
x.t("var","description");
x.t("buffer","bytes");
x.t("exceptions","thrown");
x.t("exceptions","exception");
x.t("palette","translator");
x.t("contains","following");
x.t("specify","full");
x.t("specify","operation");
x.t("specify","output");
x.t("item","operation");
x.t("item","data");
x.t("x12","edi");
x.t("resources","listed");
x.t("content","sending");
x.t("content","file");
x.t("content","translator");
x.t("content","output");
x.t("encoding","provide");
x.t("encoding","need");
x.t("encoding","file");
x.t("encoding","selection");
x.t("encoding","string");
x.t("encoding","input");
x.t("encoding","msg_content");
x.t("encoding","cause");
x.t("encoding","types");
x.t("encoding","output");
x.t("encoding","note");
x.t("encoding","used");
x.t("undesired","errors");
}
