function FileData_Pairs(x)
{
x.t("deploy","tibco");
x.t("mode","tibco");
x.t("getting","started");
x.t("testing","process");
x.t("check","process");
x.t("guide","detailed");
x.t("configuring","process");
x.t("test","mode");
x.t("test","tibco");
x.t("creating","configuring");
x.t("allows","check");
x.t("started","testing");
x.t("designer","allows");
x.t("design","guide");
x.t("software","chapter");
x.t("chapter","getting");
x.t("detailed","information");
x.t("properly","deploy");
x.t("works","properly");
x.t("tibco","designer");
x.t("tibco","software");
x.t("tibco","businessworks");
x.t("process","testing");
x.t("process","test");
x.t("process","creating");
x.t("process","design");
x.t("process","works");
x.t("process","tibco");
x.t("information","using");
x.t("businessworks","process");
x.t("using","test");
}
