function FileData_Pairs(x)
{
x.t("appendix","provides");
x.t("appendix","electronic");
x.t("basic","introduction");
x.t("introduction","electronic");
x.t("standards","tibco");
x.t("overview","structure");
x.t("provides","basic");
x.t("software","appendix");
x.t("interchange","appendix");
x.t("interchange","tibco");
x.t("interchange","(edi)");
x.t("tibco","software");
x.t("data","interchange");
x.t("(edi)","topics");
x.t("structure","standards");
x.t("topics","overview");
x.t("electronic","data");
}
