function FileData_Pairs(x)
{
x.t("root","\\demodata\\");
x.t("root","\\output\\");
x.t("root","\\output\\output.txt");
x.t("root","\\demodata\\837i_5010_h_clean.txt");
x.t("root","global");
x.t("exist","compress");
x.t("implement","different");
x.t("implement","translation");
x.t("demodata","directory");
x.t("editoedi","callbackbuffer");
x.t("business","logic");
x.t("table","shows");
x.t("table","write");
x.t("table","translatorcallback");
x.t("table","read");
x.t("create","non-existing");
x.t("callback","sample");
x.t("callback","check");
x.t("callback","function");
x.t("callback","sharedresource");
x.t("callback","shared");
x.t("performs","following");
x.t("enabled","translator");
x.t("creates","directories");
x.t("uses","map");
x.t("uses","translator");
x.t("outputs","contents");
x.t("shows","configuration");
x.t("field","input");
x.t("points","tib_translator_home");
x.t("mode","memory");
x.t("sample","projects");
x.t("sample","project");
x.t("change","map");
x.t("837i_5010_h_clean.txt","file");
x.t("837i_5010_h_clean.txt","input");
x.t("non-existing","directories");
x.t("proces","need");
x.t("text","create");
x.t("text","file");
x.t("text","input");
x.t("original","837i_5010_h_clean.txt");
x.t("updates","edi");
x.t("contents","text");
x.t("translate","edi");
x.t("operationtype","editoedi");
x.t("need","following");
x.t("file","root");
x.t("file","implement");
x.t("file","table");
x.t("file","write");
x.t("file","activity");
x.t("file","tib_b2b_home");
x.t("file","tibco");
x.t("file","translator");
x.t("file","translatorcallback");
x.t("file","read");
x.t("file","output");
x.t("file","defined");
x.t("file","edi");
x.t("file","translatercallback");
x.t("file","encoding");
x.t("file","contains");
x.t("group","callback");
x.t("check","root");
x.t("check","checkbox");
x.t("check","checkbox.the");
x.t("specified","path");
x.t("demonstrates","plug-in");
x.t("prerequisites","starting");
x.t("definition","figure");
x.t("name","write");
x.t("name","translatorcallback");
x.t("name","read");
x.t("path","already");
x.t("codes","figure");
x.t("ends","read");
x.t("\\demodata\\","directory");
x.t("bw_callback_5010_837i.map","map");
x.t("illustrates","process");
x.t("none","input");
x.t("\\examples\\translatorwithcallback_sample\\data","directory");
x.t("directories","check");
x.t("directories","specified");
x.t("map","file");
x.t("allows","change");
x.t("modifying","codes");
x.t("writes","message");
x.t("writes","output.txt");
x.t("write","text");
x.t("write","output");
x.t("plug-in","uses");
x.t("resource","implement");
x.t("resource","enabled");
x.t("resource","translate");
x.t("resource","allows");
x.t("resource","input");
x.t("resource","output");
x.t("input","mode");
x.t("input","file");
x.t("input","msg_content");
x.t("input","filename");
x.t("input","configuration");
x.t("input","edi");
x.t("onstartup","activity");
x.t("\\output\\","directory");
x.t("msg_content","content");
x.t("logic","modifying");
x.t("checkbox","enable");
x.t("button","locate");
x.t("activity","table");
x.t("activity","creates");
x.t("activity","uses");
x.t("activity","writes");
x.t("activity","write");
x.t("activity","reads");
x.t("activity","triggered");
x.t("activity","translator");
x.t("activity","translatorcallback");
x.t("activity","read");
x.t("activity","translatorwithcallback");
x.t("activity","translates");
x.t("activity","gets");
x.t("function","callback");
x.t("software","chapter");
x.t("chapter","using");
x.t("837-x223.std","guideline");
x.t("different","business");
x.t("reads","837i_5010_h_clean.txt");
x.t("reads","input");
x.t("starting","translatorwithcallback");
x.t("(bytes)","6000");
x.t("format","file");
x.t("format","message");
x.t("format","data");
x.t("directory","check");
x.t("directory","process");
x.t("directory","output");
x.t("directory","copy");
x.t("directory","translatorwithcallback");
x.t("directory","tib_translator_home");
x.t("filename","root");
x.t("checkbox.the","activity");
x.t("enable","translator");
x.t("tib_b2b_home","\\examples\\translatorwithcallback_sample\\data");
x.t("textcontent","content");
x.t("compress","none");
x.t("tibco","software");
x.t("database","directory");
x.t("triggered","load");
x.t("message","activity");
x.t("message","read");
x.t("message","content");
x.t("memory","operationtype");
x.t("memory","output");
x.t("translator","callback");
x.t("translator","activity");
x.t("projects","translator");
x.t("variable","points");
x.t("click","button");
x.t("translated","837i_5010_h_clean.txt");
x.t("project","demonstrates");
x.t("project","tibco");
x.t("project","translator");
x.t("project","translatorwithcallback");
x.t("callbackbuffer","(bytes)");
x.t("translatorwithcallback_sample","project");
x.t("configuration","name");
x.t("configuration","write");
x.t("configuration","translatorcallback");
x.t("configuration","read");
x.t("\\output\\output.txt","file");
x.t("\\output\\output.txt","textcontent");
x.t("figure","illustrates");
x.t("figure","translatorwithcallback");
x.t("\\demodata\\837i_5010_h_clean.txt","output");
x.t("6000","separator");
x.t("already","exist");
x.t("process","performs");
x.t("process","field");
x.t("process","updates");
x.t("process","definition");
x.t("process","ends");
x.t("process","translatorwithcallback_sample");
x.t("process","process");
x.t("process","translatorwithcallback");
x.t("process","starts");
x.t("translatorcallback","input");
x.t("translatorcallback","activity");
x.t("sharedresource","click");
x.t("read","text");
x.t("read","message");
x.t("output","mode");
x.t("output","contents");
x.t("output","file");
x.t("output","msg_content");
x.t("output","filename");
x.t("output","textcontent");
x.t("output","message");
x.t("data","prerequisites");
x.t("shared","resource");
x.t("defined","translator");
x.t("locate","translator");
x.t("global","variable");
x.t("translatorwithcallback","proces");
x.t("translatorwithcallback","process");
x.t("copy","837i_5010_h_clean.txt");
x.t("copy","837-x223.std");
x.t("output.txt","file");
x.t("utf-8","write");
x.t("following","copy");
x.t("following","operations");
x.t("starts","read");
x.t("translates","content");
x.t("separator","group");
x.t("using","sample");
x.t("using","bw_callback_5010_837i.map");
x.t("edi","outputs");
x.t("edi","format");
x.t("guideline","bw_callback_5010_837i.map");
x.t("translation","edi");
x.t("tib_translator_home","demodata");
x.t("tib_translator_home","directory");
x.t("tib_translator_home","database");
x.t("operations","onstartup");
x.t("load","process");
x.t("translatercallback","activity");
x.t("gets","message");
x.t("gets","content");
x.t("content","table");
x.t("content","837i_5010_h_clean.txt");
x.t("content","original");
x.t("content","text");
x.t("content","write");
x.t("content","translated");
x.t("content","using");
x.t("content","edi");
x.t("content","translatercallback");
x.t("encoding","utf-8");
x.t("contains","content");
}
