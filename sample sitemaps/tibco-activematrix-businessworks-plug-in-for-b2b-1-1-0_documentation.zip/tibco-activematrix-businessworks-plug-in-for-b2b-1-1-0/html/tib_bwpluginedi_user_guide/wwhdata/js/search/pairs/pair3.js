function FileData_Pairs(x)
{
x.t("instream-translator","process");
x.t("table","instream");
x.t("table","write");
x.t("table","translator");
x.t("table","translated");
x.t("table","translatorcallback");
x.t("table","read");
x.t("table","general");
x.t("callback","code");
x.t("callback","configuration");
x.t("tables","table");
x.t("tables","tables");
x.t("tables","tibco");
x.t("formats","table");
x.t("instream","callback");
x.t("instream","generateresponse");
x.t("instream","input");
x.t("instream","activity");
x.t("instream","configuration");
x.t("instream","documentsplitter");
x.t("instream","output");
x.t("instream","exceptions");
x.t("file","formats");
x.t("file","activity");
x.t("generateresponse","fields");
x.t("fields","table");
x.t("write","output");
x.t("input","fields");
x.t("activity","instream-translator");
x.t("activity","instreamwithcallback");
x.t("activity","translatorwithcallback");
x.t("software","tables");
x.t("code","tab");
x.t("tibco","software");
x.t("message","activity");
x.t("translator","callback");
x.t("translator","input");
x.t("translator","activity");
x.t("translator","configuration");
x.t("translator","output");
x.t("translator","exceptions");
x.t("translated","file");
x.t("configuration","fields");
x.t("instreamwithcallback","process");
x.t("documentsplitter","fields");
x.t("process","table");
x.t("process","tibco");
x.t("translatorcallback","activity");
x.t("read","message");
x.t("output","file");
x.t("output","fields");
x.t("typographical","conventions");
x.t("translatorwithcallback","process");
x.t("general","typographical");
x.t("tab","table");
x.t("conventions","table");
x.t("exceptions","table");
}
