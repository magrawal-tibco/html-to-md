function FileData_Pairs(x)
{
x.t("integration","software");
x.t("integration","projects");
x.t("integration","technology");
x.t("callback","instream");
x.t("callback","translator");
x.t("world-class","integration");
x.t("foresight","instream");
x.t("foresight","translator");
x.t("creates","user-friendly");
x.t("uses","command-line");
x.t("deployable","solution");
x.t("provided","tibco");
x.t("introduction","tibco");
x.t("access","functions");
x.t("instream","callback");
x.t("instream","validation");
x.t("instream","tibco");
x.t("instream","translator");
x.t("rapid","deployable");
x.t("overview","tibco");
x.t("perform","translation");
x.t("provides","world-class");
x.t("allows","access");
x.t("entire","lifecycle");
x.t("plug-in","b2b");
x.t("solution","manages");
x.t("functions","provided");
x.t("validation","module");
x.t("command-line","executable");
x.t("command-line","validator");
x.t("user-friendly","environment");
x.t("software","provides");
x.t("software","chapter");
x.t("chapter","introduction");
x.t("tibco","foresight");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("tibco","businessworks");
x.t("environment","allows");
x.t("projects","tibco");
x.t("translator","callback");
x.t("translator","tibco");
x.t("translator","module");
x.t("translator","following");
x.t("executable","perform");
x.t("technology","rapid");
x.t("activematrix","businessworks");
x.t("b2b","creates");
x.t("b2b","overview");
x.t("manages","entire");
x.t("module","uses");
x.t("module","command-line");
x.t("shared","resources");
x.t("lifecycle","integration");
x.t("activities","instream");
x.t("following","shared");
x.t("businessworks","plug-in");
x.t("businessworks","easy-to-use");
x.t("translation","tibco");
x.t("easy-to-use","integration");
x.t("validator","tibco");
x.t("resources","activities");
}
