function FileData_Pairs(x)
{
x.t("appendix","shows");
x.t("appendix","parsing");
x.t("hashmap","appendix");
x.t("hashmap","tibco");
x.t("hashmap","keys");
x.t("callback","java");
x.t("shows","callback");
x.t("parsing","xml");
x.t("parsing","data");
x.t("overview","parsing");
x.t("software","appendix");
x.t("xml","hashmap");
x.t("xml","format");
x.t("format","hashmap");
x.t("code","parses");
x.t("tibco","software");
x.t("java","code");
x.t("keys","values");
x.t("data","xml");
x.t("parses","data");
x.t("values","topics");
x.t("topics","overview");
}
