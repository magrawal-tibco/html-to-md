function FileData_Pairs(x)
{
x.t("appendix","electronic");
x.t("structured","predetermined");
x.t("overview","overview");
x.t("overview","tibco");
x.t("overview","electronic");
x.t("standardized","messaging");
x.t("framework","developed");
x.t("predetermined","format");
x.t("industry","groups");
x.t("exchanging","information");
x.t("developed","industry");
x.t("trading","partners");
x.t("software","appendix");
x.t("format","tibco");
x.t("partners","structured");
x.t("interchange","overview");
x.t("interchange","(edi)");
x.t("groups","exchanging");
x.t("tibco","software");
x.t("data","interchange");
x.t("messaging","framework");
x.t("information","trading");
x.t("(edi)","standardized");
x.t("electronic","data");
}
