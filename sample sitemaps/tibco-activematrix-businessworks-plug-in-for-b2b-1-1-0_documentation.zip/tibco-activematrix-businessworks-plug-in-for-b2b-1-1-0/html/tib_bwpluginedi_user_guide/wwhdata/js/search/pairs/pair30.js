function FileData_Pairs(x)
{
x.t("example","demonstrates");
x.t("shown","figure");
x.t("build","bwb2b-sample");
x.t("build","archive");
x.t("create","new");
x.t("create","enterprise");
x.t("create","ear");
x.t("create","project");
x.t("tree","left");
x.t("instructions","configure");
x.t("required","click");
x.t("upload","ear");
x.t("instance","click");
x.t("instance","process");
x.t("apply","button");
x.t("dialog","bwb2b-sample.ear");
x.t("deploy","sample");
x.t("deploy","bwb2b-sample");
x.t("deploy","ear");
x.t("deploy","button");
x.t("deploy","tibco");
x.t("deploy","successfully");
x.t("deploy","project");
x.t("deploy","configuration");
x.t("deploy","application");
x.t("administrator","deployment");
x.t("administrator","deploy");
x.t("administrator","start");
x.t("administrator","complete");
x.t("administrator","version_number");
x.t("administrator","sure");
x.t("administrator","select");
x.t("administrator","click");
x.t("administrator","services");
x.t("administrator","page");
x.t("administrator","save");
x.t("deployment","translatorwithcallback_sample");
x.t("bar","select");
x.t("state","column");
x.t("sample","projects");
x.t("sample","project");
x.t("left","side");
x.t("bwb2b-sample","enterprise");
x.t("bwb2b-sample","project");
x.t("bwb2b-sample","panel");
x.t("bwb2b-sample","service");
x.t("bwb2b-sample","folders");
x.t("want","include");
x.t("start","bwb2b-sample");
x.t("start","programs");
x.t("start","button");
x.t("start","tibco");
x.t("start","project");
x.t("start","process");
x.t("new","application");
x.t("file","shown");
x.t("file","ear");
x.t("file","tibco");
x.t("file","click");
x.t("file","generated");
x.t("file","panel");
x.t("file","using");
x.t("indicates","running");
x.t("enterprise","archive");
x.t("complete","following");
x.t("menu","bar");
x.t("add","processes");
x.t("add","process");
x.t("version_number","tibco");
x.t("browse","button");
x.t("deploying","sample");
x.t("sure","tibco");
x.t("ear","file");
x.t("ear","menu");
x.t("demonstrates","generate");
x.t("follows","similar");
x.t("tasks","task");
x.t("started","select");
x.t("programs","tibco");
x.t("resource","bwb2b-sample");
x.t("designer","create");
x.t("designer","deploy");
x.t("designer","complete");
x.t("deployed","successfully");
x.t("hawk","agent");
x.t("select","start");
x.t("select","domain");
x.t("select","tools");
x.t("select","process");
x.t("select","application");
x.t("select","service");
x.t("button","shown");
x.t("button","upload");
x.t("button","deploy");
x.t("button","bwb2b-sample");
x.t("button","new");
x.t("button","start");
x.t("button","application");
x.t("button","locate");
x.t("button","repeat");
x.t("button","note");
x.t("button","specify");
x.t("domain","log");
x.t("side","tibco");
x.t("software","chapter");
x.t("chapter","using");
x.t("processes","required");
x.t("processes","tab");
x.t("step","processes");
x.t("starting","tibco");
x.t("section","takes");
x.t("task","build");
x.t("task","deploy");
x.t("task","start");
x.t("steps","tree");
x.t("steps","add");
x.t("steps","select");
x.t("steps","starting");
x.t("folder","shown");
x.t("tibco","administrator");
x.t("tibco","designer");
x.t("tibco","hawk");
x.t("tibco","software");
x.t("tibco","tibco");
x.t("starter","archive");
x.t("successfully","shown");
x.t("successfully","indicates");
x.t("successfully","task");
x.t("projects","deploying");
x.t("click","build");
x.t("click","apply");
x.t("click","deploy");
x.t("click","new");
x.t("click","start");
x.t("click","browse");
x.t("click","button");
x.t("click","save");
x.t("project","example");
x.t("project","complete");
x.t("project","deploying");
x.t("project","ear");
x.t("project","follows");
x.t("project","section");
x.t("project","task");
x.t("project","tibco");
x.t("translatorwithcallback_sample","project");
x.t("include","shown");
x.t("configuration","bwb2b-sample");
x.t("configuration","panel");
x.t("instances","item");
x.t("similar","instructions");
x.t("tools","create");
x.t("running","state");
x.t("figure","build");
x.t("figure","create");
x.t("figure","deploy");
x.t("figure","bwb2b-sample");
x.t("figure","add");
x.t("figure","figure");
x.t("figure","application");
x.t("generate","enterprise");
x.t("process","shown");
x.t("process","starter");
x.t("process","archive");
x.t("process","starts");
x.t("process","definitions");
x.t("generated","tibco");
x.t("takes","bwb2b-sample");
x.t("panel","create");
x.t("panel","click");
x.t("panel","application");
x.t("services","started");
x.t("page","expand");
x.t("archive","file");
x.t("archive","resource");
x.t("archive","button");
x.t("archive","click");
x.t("archive","panel");
x.t("archive","(ear)");
x.t("archive","created");
x.t("configure","deploy");
x.t("save","button");
x.t("save","project");
x.t("agent","tibco");
x.t("application","deployed");
x.t("application","button");
x.t("application","tibco");
x.t("application","configuration");
x.t("application","management");
x.t("locate","ear");
x.t("expand","application");
x.t("(ear)","file");
x.t("(ear)","tibco");
x.t("repeat","steps");
x.t("note","dialog");
x.t("column","tibco");
x.t("created","step");
x.t("bwb2b-sample.ear","file");
x.t("following","tasks");
x.t("following","steps");
x.t("management","bwb2b-sample");
x.t("management","select");
x.t("management","folder");
x.t("management","panel");
x.t("service","instance");
x.t("service","instances");
x.t("starts","successfully");
x.t("using","sample");
x.t("using","tibco");
x.t("tab","click");
x.t("folders","select");
x.t("definitions","want");
x.t("log","select");
x.t("specify","process");
x.t("item","shown");
}
