function FileData_Pairs(x)
{
x.t("shown","figure");
x.t("callback","translator");
x.t("callback","activities");
x.t("includes","two");
x.t("instream","callback");
x.t("instream","translator");
x.t("overview","tibco");
x.t("overview","b2b");
x.t("software","chapter");
x.t("chapter","b2b");
x.t("tibco","software");
x.t("translator","callback");
x.t("translator","tibco");
x.t("b2b","palette");
x.t("figure","figure");
x.t("figure","b2b");
x.t("shared","resources");
x.t("activities","shown");
x.t("activities","instream");
x.t("two","shared");
x.t("two","activities");
x.t("palette","includes");
x.t("palette","overview");
x.t("palette","b2b");
x.t("palette","shared");
x.t("resources","instream");
x.t("resources","two");
}
