function FileData_Pairs(x)
{
x.t("create","enterprise");
x.t("create","project");
x.t("create","application");
x.t("build","archive");
x.t("upload","archive");
x.t("related","project");
x.t("apply","button");
x.t("deploy","deploy");
x.t("deploy","tibco");
x.t("deploy","project");
x.t("deploy","application");
x.t("deploy","associated");
x.t("administrator","create");
x.t("administrator","start");
x.t("administrator","tibco");
x.t("bar","create");
x.t("basic","procedure");
x.t("multiple","enterprise");
x.t("getting","started");
x.t("want","deploy");
x.t("start","tibco");
x.t("start","process");
x.t("single","designer");
x.t("need","generate");
x.t("file","ear");
x.t("file","generated");
x.t("file","contains");
x.t("enterprise","archive");
x.t("menu","bar");
x.t("browse","button");
x.t("deploying","project");
x.t("ear","file");
x.t("ear","menu");
x.t("definition","want");
x.t("window","select");
x.t("started","deploying");
x.t("resource","enterprise");
x.t("designer","deploy");
x.t("designer","window");
x.t("designer","project");
x.t("configured","need");
x.t("select","tools");
x.t("select","process");
x.t("button","enterprise");
x.t("button","click");
x.t("button","specify");
x.t("software","chapter");
x.t("chapter","getting");
x.t("processes","include");
x.t("processes","tab");
x.t("define","multiple");
x.t("step","processes");
x.t("tibco","administrator");
x.t("tibco","designer");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("click","build");
x.t("click","apply");
x.t("click","browse");
x.t("project","deploy");
x.t("project","deploying");
x.t("project","ear");
x.t("project","configured");
x.t("project","tibco");
x.t("project","archive");
x.t("configuration","process");
x.t("include","tibco");
x.t("include","click");
x.t("activematrix","businessworks");
x.t("tools","create");
x.t("generate","enterprise");
x.t("process","definition");
x.t("process","define");
x.t("process","archive");
x.t("process","definitions");
x.t("generated","tibco");
x.t("panel","enterprise");
x.t("archive","file");
x.t("archive","ear");
x.t("archive","resource");
x.t("archive","select");
x.t("archive","button");
x.t("archive","tibco");
x.t("archive","panel");
x.t("archive","choose");
x.t("archive","created");
x.t("archive","resources");
x.t("information","following");
x.t("save","project");
x.t("application","related");
x.t("application","start");
x.t("procedure","save");
x.t("choose","processes");
x.t("administration","information");
x.t("applications","upload");
x.t("created","step");
x.t("following","basic");
x.t("businessworks","administration");
x.t("tab","click");
x.t("associated","applications");
x.t("definitions","include");
x.t("contains","configuration");
x.t("specify","process");
x.t("resources","single");
}
