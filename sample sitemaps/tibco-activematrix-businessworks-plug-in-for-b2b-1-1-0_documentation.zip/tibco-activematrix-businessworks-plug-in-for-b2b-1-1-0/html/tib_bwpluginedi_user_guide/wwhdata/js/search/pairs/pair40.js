function FileData_Pairs(x)
{
x.t("appendix","parsing");
x.t("hashmap","parsing");
x.t("hashmap","corresponds");
x.t("hashmap","combine");
x.t("hashmap","section");
x.t("hashmap","tibco");
x.t("hashmap","keys");
x.t("hashmap","used");
x.t("key","hashmap");
x.t("key","flat");
x.t("key","extra");
x.t("key","edi");
x.t("9012345720000","type");
x.t("sender","node");
x.t("sender","information");
x.t("sample","screen");
x.t("type","key");
x.t("parsing","flat");
x.t("parsing","xml");
x.t("parsing","data");
x.t("parsing","edi");
x.t("explains","principle");
x.t("info.messagegroup","value");
x.t("text","type");
x.t("info","parent");
x.t("info","variable");
x.t("functionalgroup","nodes");
x.t("file","input");
x.t("file","data");
x.t("group","information");
x.t("flat","file");
x.t("flat","figure");
x.t("corresponds","combination");
x.t("corresponds","value");
x.t("provides","sample");
x.t("combine","parent");
x.t("input","data");
x.t("extra","key");
x.t("parent","node");
x.t("parent","nodes");
x.t("software","appendix");
x.t("combination","xml");
x.t("xml","hashmap");
x.t("xml","parent");
x.t("xml","format");
x.t("format","hashmap");
x.t("format","flat");
x.t("format","formed");
x.t("format","edi");
x.t("section","explains");
x.t("node","9012345720000");
x.t("node","sender");
x.t("node","info.messagegroup");
x.t("node","text");
x.t("node","interchange");
x.t("node","field02");
x.t("node","figure");
x.t("node","child");
x.t("node","specify");
x.t("senderqualifier","node");
x.t("interchange","functionalgroup");
x.t("interchange","node");
x.t("tibco","software");
x.t("formed","hashmap");
x.t("message","group");
x.t("forming","hashmap");
x.t("variable","value");
x.t("field02","node");
x.t("field02","child");
x.t("keys","values");
x.t("value","sender");
x.t("value","type");
x.t("value","corresponds");
x.t("value","xml");
x.t("value","field02");
x.t("figure","parsing");
x.t("figure","info");
x.t("figure","provides");
x.t("screen","info");
x.t("nodes","senderqualifier");
x.t("nodes","interchange");
x.t("nodes","child");
x.t("nodes","info.interchange.sender");
x.t("data","key");
x.t("data","flat");
x.t("data","xml");
x.t("data","format");
x.t("data","tibco");
x.t("data","value");
x.t("behind","forming");
x.t("information","key");
x.t("values","info");
x.t("values","figure");
x.t("used","demonstrate");
x.t("principle","behind");
x.t("edi","input");
x.t("edi","figure");
x.t("edi","data");
x.t("demonstrate","input");
x.t("child","node");
x.t("child","nodes");
x.t("info.interchange.sender","value");
x.t("specify","sender");
x.t("specify","message");
}
