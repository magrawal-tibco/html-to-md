function FileData_Pairs(x)
{
x.t("appendix","shows");
x.t("appendix","error");
x.t("shows","error");
x.t("codes","appendix");
x.t("codes","tibco");
x.t("plug-in","b2b");
x.t("error","codes");
x.t("software","appendix");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("activematrix","businessworks");
x.t("b2b","topics");
x.t("topics","error");
x.t("businessworks","plug-in");
}
