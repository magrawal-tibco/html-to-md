function FileData_Pairs(x)
{
x.t("root","directory");
x.t("workflows","need");
x.t("shown","figure");
x.t("create","process");
x.t("apply","button");
x.t("icon","design");
x.t("getting","started");
x.t("certain","workflows");
x.t("need","create");
x.t("complete","following");
x.t("guide","click");
x.t("creating","process");
x.t("definition","icon");
x.t("definition","configure");
x.t("started","creating");
x.t("plug-in","b2b");
x.t("designer","user\u2019s");
x.t("select","root");
x.t("button","save");
x.t("deal","certain");
x.t("drag","process");
x.t("design","panel");
x.t("software","chapter");
x.t("chapter","getting");
x.t("directory","project");
x.t("added","complete");
x.t("steps","create");
x.t("tibco","designer");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("click","apply");
x.t("project","panel");
x.t("configuration","tibco");
x.t("activematrix","businessworks");
x.t("b2b","activities");
x.t("figure","figure");
x.t("figure","process");
x.t("process","creating");
x.t("process","definition");
x.t("process","select");
x.t("process","deal");
x.t("process","tibco");
x.t("process","information");
x.t("process","palette");
x.t("panel","shown");
x.t("panel","drag");
x.t("panel","expand");
x.t("configure","process");
x.t("information","tibco");
x.t("save","configuration");
x.t("expand","process");
x.t("activities","added");
x.t("following","steps");
x.t("businessworks","plug-in");
x.t("palette","panel");
x.t("palette","palette");
x.t("user\u2019s","guide");
}
