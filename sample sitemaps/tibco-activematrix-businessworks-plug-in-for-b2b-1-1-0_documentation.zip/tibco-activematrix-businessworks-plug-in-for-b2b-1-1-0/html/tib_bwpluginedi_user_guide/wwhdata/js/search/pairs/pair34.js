function FileData_Pairs(x)
{
x.t("example","purchase");
x.t("appendix","electronic");
x.t("protocols","objective");
x.t("institute","(ansi)");
x.t("version","standards");
x.t("hundred","x12");
x.t("full","documentation");
x.t("every","facet");
x.t("commerce","transport");
x.t("business","documents");
x.t("business","function");
x.t("insurance","portability");
x.t("europe","(un/ece)");
x.t("create","html");
x.t("stands","electronic");
x.t("refers","international");
x.t("(un/ece)","flat");
x.t("today","three");
x.t("html","reports");
x.t("providing","common");
x.t("international","standards");
x.t("business-to-business","operations");
x.t("structured","data");
x.t("economic","commission");
x.t("nearly","every");
x.t("standards","institute");
x.t("standards","standards");
x.t("standards","provides");
x.t("standards","directories");
x.t("standards","supported");
x.t("standards","developed");
x.t("standards","tibco");
x.t("standards","(protocols)");
x.t("standards","following");
x.t("standards","used");
x.t("standards","edi");
x.t("standards","committee");
x.t("standards","x12");
x.t("file","standards");
x.t("file","flat");
x.t("file","data");
x.t("organization","maintains");
x.t("chartered","american");
x.t("health","insurance");
x.t("validate","flat");
x.t("validate","xml");
x.t("results","tibco");
x.t("flat","file");
x.t("accredited","standards");
x.t("common","format");
x.t("guidelines","electronic");
x.t("thousand","organizations");
x.t("objective","agreed");
x.t("accountability","act");
x.t("provides","full");
x.t("(asc)","x12");
x.t("standard","transaction");
x.t("standard","used");
x.t("directories","guidelines");
x.t("sets","used");
x.t("three","hundred");
x.t("nations","economic");
x.t("united","nations");
x.t("documents","organization");
x.t("national","standards");
x.t("supported","united");
x.t("purchase","order");
x.t("validation","results");
x.t("developed","accredited");
x.t("american","national");
x.t("(ansi)","x12");
x.t("(hipaa)","specific");
x.t("messages","based");
x.t("function","example");
x.t("software","appendix");
x.t("hipaa","health");
x.t("exchange","edifact");
x.t("edifact","stands");
x.t("edifact","refers");
x.t("edifact","standards");
x.t("edifact","edifact");
x.t("format","rules");
x.t("introductions","standards");
x.t("transport","edifact");
x.t("xml","standard");
x.t("xml","xml");
x.t("xml","data");
x.t("transmission","protocols");
x.t("reports","validation");
x.t("interchange","structured");
x.t("interchange","standards");
x.t("interchange","administration");
x.t("organizations","nearly");
x.t("tibco","software");
x.t("upon","structure");
x.t("communicating","data");
x.t("documentation","definitions");
x.t("rules","data");
x.t("brief","introductions");
x.t("specific","messages");
x.t("healthcare-related","information");
x.t("computer","systems");
x.t("agreed","upon");
x.t("thirty","thousand");
x.t("systems","edifact");
x.t("help","facilitate");
x.t("separate","computer");
x.t("data","business");
x.t("data","create");
x.t("data","xml");
x.t("data","interchange");
x.t("data","separate");
x.t("data","defined");
x.t("data","structure");
x.t("facilitate","edi");
x.t("information","exchange");
x.t("defined","business");
x.t("structure","transmission");
x.t("structure","communicating");
x.t("(protocols)","help");
x.t("transaction","sets");
x.t("transaction","contains");
x.t("administration","commerce");
x.t("portability","accountability");
x.t("based","x12");
x.t("electronic","interchange");
x.t("electronic","data");
x.t("order","today");
x.t("following","brief");
x.t("used","validate");
x.t("used","healthcare-related");
x.t("used","thirty");
x.t("edi","providing");
x.t("edi","standards");
x.t("committee","(asc)");
x.t("asc","x12");
x.t("facet","business-to-business");
x.t("maintains","standards");
x.t("definitions","version");
x.t("operations","hipaa");
x.t("act","(hipaa)");
x.t("commission","europe");
x.t("x12","standards");
x.t("x12","chartered");
x.t("x12","standard");
x.t("x12","transaction");
x.t("x12","asc");
x.t("x12","x12");
x.t("contains","data");
}
