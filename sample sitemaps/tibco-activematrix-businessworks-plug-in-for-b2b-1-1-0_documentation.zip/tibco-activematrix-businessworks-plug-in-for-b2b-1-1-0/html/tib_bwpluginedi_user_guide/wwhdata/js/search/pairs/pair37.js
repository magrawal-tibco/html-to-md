function FileData_Pairs(x)
{
x.t("tells","sender");
x.t("semantic","meaning");
x.t("appendix","acknowledgements");
x.t("reported","functional");
x.t("receiver","received");
x.t("transactions","business");
x.t("transactions","successfully");
x.t("available","x12");
x.t("interchange-level","control");
x.t("claim","acknowledgement");
x.t("claim","status");
x.t("lists","brief");
x.t("functional","acknowledgement");
x.t("functional","group");
x.t("functional","groups");
x.t("relational","analysis");
x.t("full","implemented");
x.t("(ta1)","delivery");
x.t("ansi","x12");
x.t("description","acknowledgements");
x.t("describes","syntax-level");
x.t("business","data");
x.t("delivery","acknowledgement");
x.t("syntactically","acknowledge");
x.t("997","functional");
x.t("surrounds","functional");
x.t("related","prior");
x.t("required","edifact");
x.t("(277u)","reports");
x.t("coded","free-form");
x.t("syntactical","relational");
x.t("syntactical","validation");
x.t("syntactical","analysis");
x.t("999","implementation");
x.t("implemented","subset");
x.t("payer","response");
x.t("sender","receiver");
x.t("sender","document");
x.t("(997)","describes");
x.t("ta1","997/999");
x.t("ta1","reports");
x.t("ta1","interchange");
x.t("(ta1s)","related");
x.t("responses","edifact");
x.t("response","837");
x.t("277","claim");
x.t("277","unsolicited");
x.t("acknowledgement","functional");
x.t("acknowledgement","(997)");
x.t("acknowledgement","ta1");
x.t("acknowledgement","contrl");
x.t("acknowledgement","receipt");
x.t("acknowledgement","(999)");
x.t("acknowledgement","(277ca)");
x.t("acknowledgement","edifact");
x.t("acknowledgement","reports");
x.t("acknowledgement","interchange");
x.t("acknowledgement","implementation");
x.t("editing","transaction");
x.t("acknowledging","receipt");
x.t("837","report");
x.t("contents","interchange");
x.t("contrl","document");
x.t("contrl","trading");
x.t("contrl","message");
x.t("indication","interchange");
x.t("care","claim");
x.t("(824)","reports");
x.t("document","exchanging");
x.t("document","edifact");
x.t("document","returned");
x.t("document","used");
x.t("997/999","acknowledgement");
x.t("found","acceptable");
x.t("status","notification");
x.t("status","implementation");
x.t("group","tells");
x.t("group","message");
x.t("group","transaction");
x.t("reject","error");
x.t("health","care");
x.t("results","reported");
x.t("results","syntactical");
x.t("results","application");
x.t("guide","syntax");
x.t("227ca/u","acknowledgements");
x.t("receipt","syntactical");
x.t("receipt","contents");
x.t("receipt","interchange");
x.t("receipt","x12");
x.t("(999)","first");
x.t("electronically","encoded");
x.t("cover","semantic");
x.t("prior","interchanges");
x.t("indicate","results");
x.t("standard","cover");
x.t("encoded","documents");
x.t("encoded","transaction");
x.t("segments","(ta1s)");
x.t("adjudication","277");
x.t("sets","999");
x.t("sets","ta1");
x.t("sets","results");
x.t("sets","encoded");
x.t("sets","grouped");
x.t("segment","(ta1)");
x.t("structures","acknowledgments");
x.t("defining","transactions");
x.t("contain","interchange-level");
x.t("exchanging","edifact");
x.t("(277ca)","sent");
x.t("documents","contrl");
x.t("documents","encoded");
x.t("documents","exchanged");
x.t("documents","transaction");
x.t("documents","based");
x.t("error","indication");
x.t("contrast","ansi");
x.t("validation","document");
x.t("validation","found");
x.t("syntax","edits");
x.t("first","available");
x.t("messages","used");
x.t("edits","transaction");
x.t("edits","claims");
x.t("system\u2019s","data");
x.t("control","segments");
x.t("control","structures");
x.t("control","header");
x.t("trading","partner");
x.t("trading","partners");
x.t("reporting","status");
x.t("software","appendix");
x.t("hipaa","edifact");
x.t("whether","pre-adjudication");
x.t("define","control");
x.t("may","contain");
x.t("edifact","responses");
x.t("edifact","contrl");
x.t("edifact","227ca/u");
x.t("edifact","documents");
x.t("edifact","contrast");
x.t("report","whether");
x.t("partner","agreement");
x.t("partner","note");
x.t("section","lists");
x.t("format","997");
x.t("returned","sender");
x.t("824","application");
x.t("grouped","functional");
x.t("notification","(277u)");
x.t("reports","results");
x.t("reports","receipt");
x.t("system's","data");
x.t("partners","acknowledgement");
x.t("partners","may");
x.t("level","either");
x.t("groups","ta1");
x.t("groups","used");
x.t("interchange","acknowledgement");
x.t("interchange","group");
x.t("interchange","standard");
x.t("interchange","control");
x.t("interchange","exchanged");
x.t("interchange","acknowledge");
x.t("tibco","software");
x.t("successfully","transaction");
x.t("header","trailer");
x.t("message","required");
x.t("message","acknowledgement");
x.t("message","acknowledging");
x.t("message","received");
x.t("acknowledgments","indicate");
x.t("envelope","surrounds");
x.t("envelope","envelope");
x.t("brief","description");
x.t("advice","(824)");
x.t("advice","824");
x.t("agreement","tibco");
x.t("implementation","acknowledgement");
x.t("implementation","guide");
x.t("acknowledgements","277");
x.t("acknowledgements","tibco");
x.t("acknowledgements","acknowledgements");
x.t("acknowledgements","following");
x.t("acknowledgements","used");
x.t("free-form","format");
x.t("acceptable","adjudication");
x.t("syntax-level","acknowledgement");
x.t("data","interchange");
x.t("data","content");
x.t("information","encoded");
x.t("pre-adjudication","validation");
x.t("received","trading");
x.t("received","edi");
x.t("meaning","information");
x.t("004061","subrelease");
x.t("subrelease","used");
x.t("exchanged","trading");
x.t("application","system\u2019s");
x.t("application","system's");
x.t("application","advice");
x.t("transaction","editing");
x.t("transaction","sets");
x.t("transaction","824");
x.t("transaction","level");
x.t("transaction","used");
x.t("subset","x12");
x.t("note","contrl");
x.t("two","messages");
x.t("based","full");
x.t("following","section");
x.t("used","syntactically");
x.t("used","acknowledgement");
x.t("used","defining");
x.t("used","reporting");
x.t("used","define");
x.t("used","x12");
x.t("either","coded");
x.t("edi","transactions");
x.t("unsolicited","health");
x.t("trailer","interchange");
x.t("trailer","envelope");
x.t("interchanges","contrl");
x.t("analysis","electronically");
x.t("analysis","interchange");
x.t("acknowledge","reject");
x.t("acknowledge","segment");
x.t("claims","transaction");
x.t("sent","payer");
x.t("x12","functional");
x.t("x12","hipaa");
x.t("x12","004061");
x.t("x12","transaction");
x.t("x12","two");
x.t("content","edits");
}
