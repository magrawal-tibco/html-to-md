function FileData_Pairs(x)
{
x.t("describes","b2b");
x.t("callback","instream");
x.t("callback","translator");
x.t("includes","shared");
x.t("instream","callback");
x.t("instream","translator");
x.t("overview","instream");
x.t("plug-in","b2b");
x.t("software","chapter");
x.t("chapter","describes");
x.t("chapter","b2b");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("translator","callback");
x.t("translator","tibco");
x.t("activematrix","businessworks");
x.t("b2b","topics");
x.t("b2b","palette");
x.t("shared","resources");
x.t("activities","tibco");
x.t("topics","b2b");
x.t("businessworks","plug-in");
x.t("palette","includes");
x.t("palette","overview");
x.t("palette","chapter");
x.t("palette","tibco");
x.t("resources","activities");
}
