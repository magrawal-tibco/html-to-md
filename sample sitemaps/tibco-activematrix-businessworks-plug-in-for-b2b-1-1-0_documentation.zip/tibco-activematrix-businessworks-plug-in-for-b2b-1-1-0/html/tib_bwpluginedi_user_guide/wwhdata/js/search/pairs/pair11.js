function FileData_Pairs(x)
{
x.t("describes","basic");
x.t("required","configure");
x.t("variables","tibco");
x.t("basic","steps");
x.t("getting","started");
x.t("testing","process");
x.t("overview","creating");
x.t("deploying","project");
x.t("creating","project");
x.t("creating","process");
x.t("started","chapter");
x.t("started","tibco");
x.t("plug-in","b2b");
x.t("defining","global");
x.t("designer","topics");
x.t("software","chapter");
x.t("chapter","describes");
x.t("chapter","getting");
x.t("steps","required");
x.t("tibco","designer");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("project","creating");
x.t("project","defining");
x.t("activematrix","businessworks");
x.t("b2b","tibco");
x.t("b2b","palette");
x.t("process","testing");
x.t("process","deploying");
x.t("process","adding");
x.t("configure","run");
x.t("activities","process");
x.t("global","variables");
x.t("topics","b2b");
x.t("run","tibco");
x.t("businessworks","plug-in");
x.t("adding","activities");
x.t("palette","overview");
}
