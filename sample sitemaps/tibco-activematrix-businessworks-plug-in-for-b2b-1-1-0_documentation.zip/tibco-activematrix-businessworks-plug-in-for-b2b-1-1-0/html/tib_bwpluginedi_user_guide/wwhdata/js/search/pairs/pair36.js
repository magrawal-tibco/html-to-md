function FileData_Pairs(x)
{
x.t("appendix","acknowledgements");
x.t("provide","feedback");
x.t("transactions","sent");
x.t("claim","acknowledgement");
x.t("claim","status");
x.t("business","level");
x.t("997","999");
x.t("999","used");
x.t("sender","transaction");
x.t("acknowledgement","(277ca)");
x.t("acknowledgement","used");
x.t("277","claim");
x.t("277","277");
x.t("277","unsolicited");
x.t("contrl","acknowledgement");
x.t("acceptance","transaction");
x.t("care","claim");
x.t("care","industry");
x.t("status","acceptance");
x.t("status","notification");
x.t("health","care");
x.t("overview","overview");
x.t("overview","tibco");
x.t("overview","acknowledgements");
x.t("industry","report");
x.t("(277ca)","824");
x.t("give","feedback");
x.t("validation","success");
x.t("trading","partners");
x.t("edits","business-level");
x.t("software","appendix");
x.t("hipaa","acknowledgements");
x.t("edifact","contrl");
x.t("report","validation");
x.t("purpose","hipaa");
x.t("824","application");
x.t("partners","validation");
x.t("notification","277");
x.t("level","application");
x.t("tibco","software");
x.t("failure","transactions");
x.t("failure","business");
x.t("advice","tibco");
x.t("acknowledgements","997");
x.t("acknowledgements","277");
x.t("acknowledgements","overview");
x.t("acknowledgements","used");
x.t("application","edits");
x.t("application","advice");
x.t("feedback","sender");
x.t("feedback","trading");
x.t("transaction","status");
x.t("transaction","recipient");
x.t("recipient","x12");
x.t("used","provide");
x.t("used","health");
x.t("used","give");
x.t("used","purpose");
x.t("unsolicited","health");
x.t("success","failure");
x.t("business-level","acknowledgements");
x.t("sent","edifact");
x.t("x12","acknowledgements");
}
