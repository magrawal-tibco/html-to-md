function FileData_Pairs(x)
{
x.t("appendix","provides");
x.t("appendix","acknowledgements");
x.t("introduction","acknowledgements");
x.t("overview","acknowledgements");
x.t("provides","brief");
x.t("plug-in","b2b");
x.t("supported","tibco");
x.t("software","appendix");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("brief","introduction");
x.t("activematrix","businessworks");
x.t("b2b","topics");
x.t("acknowledgements","appendix");
x.t("acknowledgements","supported");
x.t("acknowledgements","tibco");
x.t("topics","overview");
x.t("businessworks","plug-in");
}
