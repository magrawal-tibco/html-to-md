function FileData_Pairs(x)
{
x.t("provide","easy");
x.t("easy","defaults");
x.t("shown","figure");
x.t("create","new");
x.t("create","global");
x.t("variables","provide");
x.t("variables","dialog");
x.t("variables","defining");
x.t("variables","tibco");
x.t("variables","click");
x.t("variables","panel");
x.t("variables","global");
x.t("variables","tab");
x.t("dialog","appears");
x.t("delete","global");
x.t("getting","started");
x.t("details","section");
x.t("new","variable");
x.t("new","global");
x.t("start","tibco");
x.t("complete","following");
x.t("add","variable");
x.t("group","update");
x.t("guide","details");
x.t("defaults","throughout");
x.t("name","value");
x.t("name","column");
x.t("double-click","variable");
x.t("started","defining");
x.t("defining","global");
x.t("designer","click");
x.t("designer","user\u2019s");
x.t("respectively","click");
x.t("button","delete");
x.t("button","add");
x.t("button","enter");
x.t("button","click");
x.t("button","global");
x.t("appears","shown");
x.t("software","chapter");
x.t("chapter","getting");
x.t("specifies","create");
x.t("section","specifies");
x.t("steps","create");
x.t("tibco","designer");
x.t("tibco","software");
x.t("throughout","project");
x.t("variable","start");
x.t("variable","complete");
x.t("variable","group");
x.t("variable","name");
x.t("variable","double-click");
x.t("variable","button");
x.t("variable","click");
x.t("variable","update");
x.t("click","add");
x.t("click","button");
x.t("click","global");
x.t("enter","variable");
x.t("project","tibco");
x.t("value","name");
x.t("value","tibco");
x.t("value","column");
x.t("figure","create");
x.t("figure","figure");
x.t("figure","global");
x.t("panel","global");
x.t("global","variables");
x.t("global","variable");
x.t("column","respectively");
x.t("column","value");
x.t("predefined","global");
x.t("following","steps");
x.t("tab","shown");
x.t("tab","click");
x.t("user\u2019s","guide");
x.t("update","name");
x.t("update","predefined");
}
