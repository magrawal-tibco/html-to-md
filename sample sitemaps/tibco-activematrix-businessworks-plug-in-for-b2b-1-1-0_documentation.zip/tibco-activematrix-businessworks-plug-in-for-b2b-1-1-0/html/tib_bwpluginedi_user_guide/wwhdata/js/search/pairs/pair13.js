function FileData_Pairs(x)
{
x.t("files","define");
x.t("create","select");
x.t("create","project");
x.t("microsoft","windows");
x.t("execute","following");
x.t("dialog","navigate");
x.t("dialog","figure");
x.t("open","tibco");
x.t("bin\\designer.exe","unix");
x.t("change","tibco_home");
x.t("getting","started");
x.t("start","programs");
x.t("start","tibco");
x.t("start","screen");
x.t("new","empty");
x.t("command","window");
x.t("multi-file","project");
x.t("during","runtime");
x.t("complete","following");
x.t("tibco_home","designer");
x.t("version_number","bin\\designer.exe");
x.t("version_number","tibco");
x.t("version_number","bin");
x.t("navigate","location");
x.t("creating","project");
x.t("name","project");
x.t("window","microsoft");
x.t("window","change");
x.t("window","run");
x.t("continue","figure");
x.t("started","creating");
x.t("programs","tibco");
x.t("empty","project");
x.t("plug-in","starting");
x.t("designer","create");
x.t("designer","execute");
x.t("designer","dialog");
x.t("designer","start");
x.t("designer","command");
x.t("designer","version_number");
x.t("designer","window");
x.t("designer","gui");
x.t("designer","click");
x.t("designer","save");
x.t("commands","open");
x.t("select","start");
x.t("select","project");
x.t("options","used");
x.t("button","multi-file");
x.t("button","continue");
x.t("button","tibco");
x.t("appears","newly");
x.t("gui","appears");
x.t("gui","used");
x.t("software","chapter");
x.t("chapter","getting");
x.t("define","options");
x.t("starting","tibco");
x.t("unix","command");
x.t("directory","run");
x.t("steps","create");
x.t("tibco","designer");
x.t("tibco","software");
x.t("tibco","tibco");
x.t("click","new");
x.t("click","button");
x.t("project","dialog");
x.t("project","start");
x.t("project","creating");
x.t("project","button");
x.t("project","tibco");
x.t("project","click");
x.t("project","project");
x.t("project","panel");
x.t("project","screen");
x.t("project","contains");
x.t("project","specify");
x.t("windows","select");
x.t("configuration","files");
x.t("bin","directory");
x.t("figure","tibco");
x.t("platform-specific","commands");
x.t("screen","tibco");
x.t("screen","click");
x.t("panel","save");
x.t("location","intend");
x.t("configure","plug-in");
x.t("save","project");
x.t("newly","created");
x.t("runtime","complete");
x.t("intend","save");
x.t("created","project");
x.t("used","during");
x.t("used","configure");
x.t("following","steps");
x.t("following","platform-specific");
x.t("run","tibco_home");
x.t("run","designer");
x.t("contains","configuration");
x.t("specify","name");
}
