function FileData_Pairs(x)
{
x.t("csv","file");
x.t("example","name");
x.t("example","partnerautomationflat=");
x.t("included","project");
x.t("method","implemented");
x.t("method","profiles");
x.t("method","parse");
x.t("method","guidelines");
x.t("method","updateanalysis");
x.t("method","input");
x.t("method","called");
x.t("appendix","parsing");
x.t("c:\\bwprojects\\edi\\data\\sampleflatfilepartnerautomation5.csv","configuration");
x.t("library","allows");
x.t("properties","section");
x.t("hashmap","details");
x.t("hashmap","input");
x.t("hashmap","keys");
x.t("hashmap","data");
x.t("hashmap","using");
x.t("implement","business");
x.t("implement","different");
x.t("functional","group");
x.t("every","group");
x.t("files","need");
x.t("files","tibco");
x.t("comment","global");
x.t("needs","compilation");
x.t("business","logic");
x.t("table","instream");
x.t("description","description");
x.t("description","dialog");
x.t("description","short");
x.t("description","name");
x.t("description","activity");
x.t("description","java");
x.t("callback","instream");
x.t("callback","checkbox");
x.t("callback","code");
x.t("callback","tibco");
x.t("callback","configuration");
x.t("callback","shared");
x.t("callback","happens");
x.t("variables","accessed");
x.t("variables","java");
x.t("variables","mentioned");
x.t("source","code");
x.t("alias","library");
x.t("current","source");
x.t("implemented","parse");
x.t("field","source");
x.t("field","global");
x.t("field","modify");
x.t("dialog","alias");
x.t("dialog","appear");
x.t("uses","aliaslibrary");
x.t("locations","jar");
x.t("icon","appears");
x.t("errors","dialog");
x.t("errors","button");
x.t("errors","code");
x.t("errors","encountered");
x.t("displays","source");
x.t("displays","errors");
x.t("callbackxmlutil.parsetohashmap","method");
x.t("time","new");
x.t("enveloping","headers");
x.t("enveloping","encountered");
x.t("form","hashmap");
x.t("parsing","data");
x.t("compiles","current");
x.t("yellow","warning");
x.t("default","updateanalysis");
x.t("property","$dir.ini");
x.t("$dir.ini","instream");
x.t("contents","data");
x.t("access","clicking");
x.t("new","flat");
x.t("new","edi");
x.t("consists","information");
x.t("details","aliaslibrary");
x.t("details","parse");
x.t("details","code");
x.t("element","description");
x.t("instream","callback");
x.t("instream","activity");
x.t("instream","configuration");
x.t("aliaslibrary","resource");
x.t("profiles","assign");
x.t("profiles","guidelines");
x.t("profiles","modifying");
x.t("profiles","java");
x.t("profiles","based");
x.t("clicking","code");
x.t("info","variable");
x.t("file","appendix");
x.t("file","callbackxmlutil.parsetohashmap");
x.t("file","input");
x.t("file","format");
x.t("file","located");
x.t("file","header");
x.t("file","correctly");
x.t("file","mentioned");
x.t("need","included");
x.t("need","enable");
x.t("short","description");
x.t("assign","value");
x.t("group","enveloping");
x.t("group","level");
x.t("add","description");
x.t("jar","files");
x.t("callback_x12-1","package");
x.t("check","callback");
x.t("validate","flat");
x.t("guide","details");
x.t("parse","info");
x.t("parse","value");
x.t("flat","file");
x.t("directly","implement");
x.t("directly","assign");
x.t("guidelines","profiles");
x.t("guidelines","setprofileoptions");
x.t("name","example");
x.t("name","instream");
x.t("name","name");
x.t("name","activity");
x.t("definition","description");
x.t("codes","implement");
x.t("codes","using");
x.t("changed","callback_x121");
x.t("edit","class");
x.t("entered",".csv");
x.t("methods","variables");
x.t("methods","setguideline");
x.t("profile","directly");
x.t("partnerautomationflat=","c:\\bwprojects\\edi\\data\\sampleflatfilepartnerautomation5.csv");
x.t("standard","java");
x.t("allows","select");
x.t("allows","modify");
x.t("allows","specify");
x.t("modifying","updateanalysis");
x.t("modifying","java");
x.t("string","val");
x.t("updateanalysis","method");
x.t("fields","table");
x.t("fields","field");
x.t("accessed","instream");
x.t("resource","access");
x.t("resource","callback_x12-1");
x.t("resource","check");
x.t("resource","validate");
x.t("resource","name");
x.t("resource","allows");
x.t("resource","code");
x.t("resource","general");
x.t("input","flat");
x.t("input","data");
x.t("input","data\u2019s");
x.t("designer","uses");
x.t("designer","user\u2019s");
x.t("logic","implement");
x.t("logic","modifying");
x.t("logic","enable");
x.t("display","errors");
x.t("validation","guidelines");
x.t("checkbox","instream");
x.t("respectively","code");
x.t("select","validation");
x.t("headers","information");
x.t("button","displays");
x.t("button","compiles");
x.t("button","add");
x.t("button","code");
x.t("appears","button");
x.t("activity","needs");
x.t("activity","click");
x.t("activity","configuration");
x.t("activity","process");
x.t("gui","element");
x.t("gui","elements");
x.t("setguideline","string");
x.t("comments","say");
x.t("software","chapter");
x.t("chapter","b2b");
x.t("different","business");
x.t("editor","tibco");
x.t("extracted","time");
x.t("extracted","new");
x.t("extracted","input");
x.t("extracted","edi");
x.t("callback_x121","respectively");
x.t("callback_x121","callback_x121");
x.t("accessing","tibco");
x.t("section","tibco");
x.t("section","defined");
x.t("profileoptions","variable");
x.t("format","hashmap");
x.t("format","form");
x.t("format","consists");
x.t("format","updateanalysis");
x.t("xml","format");
x.t("compile","button");
x.t("compile","successfully");
x.t("code","field");
x.t("code","instream");
x.t("code","allows");
x.t("code","activity");
x.t("code","editor");
x.t("code","accessing");
x.t("code","compile");
x.t("code","code");
x.t("code","java");
x.t("code","named");
x.t("code","view");
x.t("code","package");
x.t("code","either");
x.t("code","tab");
x.t("code","compiled");
x.t("enable","instream");
x.t("enable","partnerautomationflat");
x.t("reference","details");
x.t("level","default");
x.t("interchange","functional");
x.t("located","tib_instream_home");
x.t("folder","value");
x.t("tibco","designer");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("header","information");
x.t("successfully","view");
x.t("appear","display");
x.t("java","codes");
x.t("java","code");
x.t("java","system");
x.t("java","class");
x.t("java","naming");
x.t("variable","profile");
x.t("variable","xml");
x.t("variable","value");
x.t("variable","guideline");
x.t("click","button");
x.t("project","tibco");
x.t("configuration","file");
x.t("configuration","fields");
x.t("configuration","configuration");
x.t("configuration","tab");
x.t("keys","values");
x.t("partnerautomationflat","csv");
x.t("partnerautomationflat","property");
x.t("setprofileoptions","string");
x.t("value","info");
x.t("value","profileoptions");
x.t("value","xml");
x.t("value","partnerautomationflat");
x.t("value","guideline");
x.t("bin","folder");
x.t("named","using");
x.t("activematrix","businessworks");
x.t("b2b","palette");
x.t("process","definition");
x.t("compilation","yellow");
x.t("view","errors");
x.t("encountered","appendix");
x.t("encountered","instream");
x.t("encountered","code");
x.t("third-party","jar");
x.t("data","need");
x.t("data","flat");
x.t("data","modifying");
x.t("data","xml");
x.t("data","structure");
x.t("data","correctly");
x.t("data","edi");
x.t("data\u2019s","functional");
x.t("data\u2019s","interchange");
x.t("information","extracted");
x.t("shared","resource");
x.t("defined","java");
x.t("happens","every");
x.t("values","value");
x.t("called","time");
x.t("called","flat");
x.t("structure","value");
x.t("tib_instream_home","bin");
x.t("above","example");
x.t("global","variables");
x.t("global","var");
x.t("two","methods");
x.t(".csv","configuration");
x.t("based","contents");
x.t("based","instream");
x.t("mentioned","section");
x.t("mentioned","above");
x.t("val","method");
x.t("correctly","entered");
x.t("package","class");
x.t("following","fields");
x.t("following","gui");
x.t("following","two");
x.t("say","modify");
x.t("system","properties");
x.t("elements","table");
x.t("either","compile");
x.t("using","instream");
x.t("using","standard");
x.t("using","following");
x.t("guideline","directly");
x.t("guideline","variable");
x.t("edi","input");
x.t("edi","format");
x.t("edi","data\u2019s");
x.t("general","palette");
x.t("class","button");
x.t("class","names");
x.t("class","specify");
x.t("businessworks","global");
x.t("businessworks","palette");
x.t("warning","icon");
x.t("tab","guidelines");
x.t("tab","methods");
x.t("tab","gui");
x.t("tab","java");
x.t("tab","contains");
x.t("modify","comment");
x.t("modify","codes");
x.t("modify","content");
x.t("names","changed");
x.t("names","java");
x.t("var","description");
x.t("compiled","edit");
x.t("naming","conventions");
x.t("conventions","based");
x.t("palette","instream");
x.t("palette","reference");
x.t("palette","specify");
x.t("contains","following");
x.t("specify","locations");
x.t("specify","validation");
x.t("specify","third-party");
x.t("user\u2019s","guide");
x.t("content","comments");
}
