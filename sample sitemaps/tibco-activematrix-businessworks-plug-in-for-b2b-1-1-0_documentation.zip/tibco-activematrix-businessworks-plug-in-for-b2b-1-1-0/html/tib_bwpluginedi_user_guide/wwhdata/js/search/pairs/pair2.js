function FileData_Pairs(x)
{
x.t("instream-translator","process");
x.t("create","new");
x.t("create","global");
x.t("build","archive");
x.t("variables","figure");
x.t("variables","tab");
x.t("instance","figure");
x.t("administrator","figure");
x.t("deploy","successfully");
x.t("deploy","application");
x.t("parsing","flat");
x.t("parsing","edi");
x.t("start","screen");
x.t("bwb2b-sample","global");
x.t("bwb2b-sample","service");
x.t("new","application");
x.t("info","variable");
x.t("file","data");
x.t("add","process");
x.t("flat","file");
x.t("definition","figure");
x.t("figures","figures");
x.t("figures","tibco");
x.t("figures","figure");
x.t("designer","start");
x.t("designer","save");
x.t("processing","workflow");
x.t("software","figures");
x.t("workflow","figure");
x.t("xml","format");
x.t("format","figure");
x.t("tibco","administrator");
x.t("tibco","designer");
x.t("tibco","software");
x.t("starter","archive");
x.t("successfully","figure");
x.t("variable","value");
x.t("project","screen");
x.t("instreamwithcallback","process");
x.t("value","xml");
x.t("figure","instream-translator");
x.t("figure","create");
x.t("figure","build");
x.t("figure","deploy");
x.t("figure","parsing");
x.t("figure","bwb2b-sample");
x.t("figure","info");
x.t("figure","add");
x.t("figure","tibco");
x.t("figure","instreamwithcallback");
x.t("figure","b2b");
x.t("figure","process");
x.t("figure","application");
x.t("figure","global");
x.t("figure","translatorwithcallback");
x.t("figure","edi");
x.t("figure","translation");
x.t("b2b","palette");
x.t("process","definition");
x.t("process","starter");
x.t("process","figure");
x.t("screen","figure");
x.t("archive","figure");
x.t("data","tibco");
x.t("data","figure");
x.t("save","project");
x.t("application","tibco");
x.t("application","management");
x.t("global","variables");
x.t("structure","figure");
x.t("translatorwithcallback","process");
x.t("management","figure");
x.t("service","instance");
x.t("edi","processing");
x.t("edi","data");
x.t("edi","structure");
x.t("translation","workflow");
x.t("tab","figure");
x.t("palette","figure");
}
