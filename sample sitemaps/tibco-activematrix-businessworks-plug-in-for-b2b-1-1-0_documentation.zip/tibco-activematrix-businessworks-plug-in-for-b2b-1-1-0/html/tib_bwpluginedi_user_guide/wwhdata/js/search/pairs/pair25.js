function FileData_Pairs(x)
{
x.t("describes","sample");
x.t("callback","sample");
x.t("working","sample");
x.t("sample","projects");
x.t("sample","project");
x.t("operates","topics");
x.t("overview","setting");
x.t("deploying","sample");
x.t("plug-in","b2b");
x.t("understand","tibco");
x.t("software","chapter");
x.t("chapter","describes");
x.t("chapter","using");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("projects","chapter");
x.t("projects","tibco");
x.t("projects","help");
x.t("projects","packaged");
x.t("translator","callback");
x.t("project","deploying");
x.t("project","tibco");
x.t("project","translator");
x.t("project","bwb2b");
x.t("bwb2b","sample");
x.t("activematrix","businessworks");
x.t("b2b","working");
x.t("b2b","operates");
x.t("help","understand");
x.t("topics","overview");
x.t("using","sample");
x.t("businessworks","plug-in");
x.t("setting","sample");
x.t("packaged","tibco");
}
