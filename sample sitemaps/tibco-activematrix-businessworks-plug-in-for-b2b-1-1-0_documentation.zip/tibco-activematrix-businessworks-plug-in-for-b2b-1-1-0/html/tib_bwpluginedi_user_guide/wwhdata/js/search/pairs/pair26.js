function FileData_Pairs(x)
{
x.t("exist","run");
x.t("instream-translator","process");
x.t("files","already");
x.t("files","appropriate");
x.t("callback","shared");
x.t("mode","order");
x.t("sample","projects");
x.t("listed","above");
x.t("bwb2b-sample","project");
x.t("\\examples","directory");
x.t("includes","instream");
x.t("includes","translator");
x.t("instream","callback");
x.t("file","output");
x.t("file","therefore");
x.t("overview","bwb2b-sample");
x.t("overview","overview");
x.t("overview","tibco");
x.t("demonstrates","plug-in");
x.t("avoid","error");
x.t("plug-in","located");
x.t("plug-in","b2b");
x.t("resource","translatorwithcallback");
x.t("resource","following");
x.t("input","file");
x.t("error","indicating");
x.t("indicating","output");
x.t("software","chapter");
x.t("chapter","using");
x.t("processes","instream-translator");
x.t("processes","listed");
x.t("processes","move");
x.t("move","output");
x.t("directory","bwb2b-sample");
x.t("located","tib_b2b_home");
x.t("tib_b2b_home","\\examples");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("projects","overview");
x.t("translator","callback");
x.t("project","includes");
x.t("project","translatorwithcallback_sample");
x.t("project","associated");
x.t("translatorwithcallback_sample","project");
x.t("instreamwithcallback","process");
x.t("activematrix","businessworks");
x.t("b2b","installation");
x.t("already","exist");
x.t("process","tibco");
x.t("process","instreamwithcallback");
x.t("process","two");
x.t("process","translatorwithcallback");
x.t("output","files");
x.t("output","mode");
x.t("location","run");
x.t("shared","resource");
x.t("appropriate","location");
x.t("above","input");
x.t("two","processes");
x.t("translatorwithcallback","project");
x.t("translatorwithcallback","process");
x.t("order","avoid");
x.t("following","processes");
x.t("run","processes");
x.t("run","process");
x.t("using","sample");
x.t("businessworks","plug-in");
x.t("installation","demonstrates");
x.t("associated","tibco");
x.t("therefore","file");
}
