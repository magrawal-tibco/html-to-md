function FileData_Pairs(x)
{
x.t("foresight","overview");
x.t("foresight","tibco");
x.t("introduction","chapter");
x.t("introduction","tibco");
x.t("overview","tibco");
x.t("plug-in","b2b");
x.t("software","chapter");
x.t("chapter","introduction");
x.t("chapter","gives");
x.t("tibco","foresight");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("activematrix","businessworks");
x.t("gives","overview");
x.t("b2b","overview");
x.t("b2b","topics");
x.t("topics","tibco");
x.t("businessworks","plug-in");
}
