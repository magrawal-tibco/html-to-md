function FileData_Pairs(x)
{
x.t("example","c:\\output\\");
x.t("instream-translator","process");
x.t("implement","validation");
x.t("implement","different");
x.t("inbound","edi");
x.t("files","xml");
x.t("files","generated");
x.t("files","using");
x.t("every","valid");
x.t("table","shows");
x.t("table","instream");
x.t("table","translator");
x.t("output_file","outputfolder");
x.t("business","logic");
x.t("callback","check");
x.t("callback","resource");
x.t("callback","function");
x.t("callback","sharedresource");
x.t("callback","shared");
x.t("once","every");
x.t("once","last");
x.t("performs","following");
x.t("summary","file");
x.t("summary","results");
x.t("837iclean_ds_report.xml","ds_rpt_valid_filename");
x.t("837iclean_ds_report.xml","document");
x.t("guideline_name","837aq320");
x.t("c:\\output\\","output");
x.t("creates","detail");
x.t("enabled","instream");
x.t("uses","instream");
x.t("uses","837aq320");
x.t("837iclean_detail_result.txt","validation");
x.t("837iclean_detail_result.txt","validation_summaryfile");
x.t("last","valid");
x.t("shows","configuration");
x.t("field","input");
x.t("mode","file");
x.t("sample","projects");
x.t("sample","project");
x.t("type","report");
x.t("type","editoxml");
x.t("change","guidelines");
x.t("input_file","inputfolder");
x.t("input_file","output");
x.t("ds_rpt_valid_filename","outputfolder");
x.t("validates","837iclean.txt");
x.t("validates","input");
x.t("demo3_edi_to_xml_837i","input_file");
x.t("demo3_edi_to_xml_837i","map");
x.t("instream","callback");
x.t("instream","input");
x.t("instream","activity");
x.t("document","splitter");
x.t("837iclean.txt","file");
x.t("837iclean.txt","output_directory");
x.t("file","callback");
x.t("file","837iclean_ds_report.xml");
x.t("file","837iclean_detail_result.txt");
x.t("file","group");
x.t("file","processed");
x.t("file","837iclean_ds_valid_00001.txt");
x.t("file","operation");
x.t("file","837iclean_summary_result.txt");
x.t("file","translator");
x.t("file","documentsplitter");
x.t("file","generated");
x.t("file","output");
x.t("file","using");
x.t("file","including");
x.t("profiles","implement");
x.t("group","iterates");
x.t("validate","837iclean.txt");
x.t("validate","edi");
x.t("837iclean_ds_valid_00001_xml.xml","translated");
x.t("837iclean_ds_valid_00001_xml.xml","encoding");
x.t("results","generates");
x.t("check","checkbox");
x.t("processed","837iclean_ds_valid_00001_xml.xml");
x.t("demonstrates","validation");
x.t("837iclean_ds_valid_00001.txt","validate");
x.t("837iclean_ds_valid_00001.txt","translator");
x.t("name","instream");
x.t("name","translator");
x.t("operation","type");
x.t("guidelines","profiles");
x.t("definition","figure");
x.t("ends","instream");
x.t("codes","figure");
x.t("illustrates","process");
x.t("map","file");
x.t("allows","change");
x.t("modifying","codes");
x.t("plug-in","uses");
x.t("resource","implement");
x.t("resource","enabled");
x.t("resource","creates");
x.t("resource","validate");
x.t("resource","allows");
x.t("resource","input");
x.t("onstartup","activity");
x.t("input","guideline_name");
x.t("input","mode");
x.t("input","input_file");
x.t("input","map_filename");
x.t("input","configuration");
x.t("input","edi");
x.t("functions","work");
x.t("validation_resultfile","outputfolder");
x.t("logic","modifying");
x.t("validation","summary");
x.t("validation","document");
x.t("validation","result");
x.t("validation","guideline");
x.t("validation","translation");
x.t("checkbox","enable");
x.t("button","locate");
x.t("activity","instream-translator");
x.t("activity","table");
x.t("activity","once");
x.t("activity","uses");
x.t("activity","validates");
x.t("activity","instream");
x.t("activity","input");
x.t("activity","xml");
x.t("activity","transits");
x.t("activity","(ds_rpt_valid_filename)");
x.t("activity","triggered");
x.t("activity","translator");
x.t("activity","instreamwithcallback");
x.t("activity","translates");
x.t("iterates","once");
x.t("outputfolder","example");
x.t("outputfolder","837iclean_ds_report.xml");
x.t("outputfolder","837iclean_detail_result.txt");
x.t("outputfolder","837iclean_ds_valid_00001_xml.xml");
x.t("outputfolder","837iclean_ds_valid_00001.txt");
x.t("outputfolder","837iclean_summary_result.txt");
x.t("function","callback");
x.t("function","instream");
x.t("software","chapter");
x.t("chapter","using");
x.t("different","business");
x.t("report","type");
x.t("report","file");
x.t("report","format");
x.t("inputfolder","837iclean.txt");
x.t("format","files");
x.t("format","table");
x.t("format","xml");
x.t("format","data");
x.t("xml","input");
x.t("xml","format");
x.t("map_filename","demo3_edi_to_xml_837i");
x.t("837iclean_summary_result.txt","file");
x.t("837iclean_summary_result.txt","validation");
x.t("837iclean_summary_result.txt","tibco");
x.t("837iclean_summary_result.txt","ds_report_filename");
x.t("end","activity");
x.t("invalid","file");
x.t("invalid","data");
x.t("enable","instream");
x.t("transits","end");
x.t("validation_summaryfile","outputfolder");
x.t("(ds_rpt_valid_filename)","output_directory");
x.t("tibco","software");
x.t("triggered","load");
x.t("837aq320","input_file");
x.t("837aq320","guideline");
x.t("output_directory","outputfolder");
x.t("projects","bwb2b");
x.t("translator","input");
x.t("translator","activity");
x.t("together","process");
x.t("translated","file");
x.t("click","button");
x.t("bwb2b","sample");
x.t("project","instream-translator");
x.t("project","tibco");
x.t("project","bwb2b");
x.t("project","demonstrate");
x.t("instreamwithcallback","process");
x.t("configuration","instream");
x.t("configuration","name");
x.t("configuration","translator");
x.t("figure","instream-translator");
x.t("figure","illustrates");
x.t("figure","instreamwithcallback");
x.t("documentsplitter","report");
x.t("editoxml","input");
x.t("process","instream-translator");
x.t("process","inbound");
x.t("process","performs");
x.t("process","field");
x.t("process","instream");
x.t("process","demonstrates");
x.t("process","definition");
x.t("process","ends");
x.t("process","bwb2b");
x.t("process","instreamwithcallback");
x.t("process","process");
x.t("process","starts");
x.t("generated","837iclean_detail_result.txt");
x.t("generated","instream");
x.t("generated","process");
x.t("generated","case");
x.t("sharedresource","click");
x.t("valid","file");
x.t("valid","edi");
x.t("output","output_file");
x.t("output","mode");
x.t("output","instream");
x.t("output","validation_resultfile");
x.t("data","instream-translator");
x.t("data","invalid");
x.t("ds_report_filename","outputfolder");
x.t("shared","resource");
x.t("result","file");
x.t("defined","instream");
x.t("case","table");
x.t("locate","instream");
x.t("work","together");
x.t("utf-8","instreamwithcallback");
x.t("following","files");
x.t("following","operations");
x.t("starts","instream");
x.t("translates","837iclean_ds_valid_00001.txt");
x.t("translates","valid");
x.t("using","sample");
x.t("using","demo3_edi_to_xml_837i");
x.t("using","document");
x.t("using","validation");
x.t("using","837aq320");
x.t("demonstrate","plug-in");
x.t("edi","files");
x.t("edi","creates");
x.t("edi","file");
x.t("edi","format");
x.t("edi","figure");
x.t("edi","generated");
x.t("edi","data");
x.t("edi","using");
x.t("guideline","defined");
x.t("guideline","following");
x.t("translation","functions");
x.t("translation","edi");
x.t("operations","onstartup");
x.t("load","process");
x.t("including","valid");
x.t("generates","file");
x.t("splitter","function");
x.t("splitter","report");
x.t("splitter","translation");
x.t("detail","summary");
x.t("encoding","utf-8");
}
