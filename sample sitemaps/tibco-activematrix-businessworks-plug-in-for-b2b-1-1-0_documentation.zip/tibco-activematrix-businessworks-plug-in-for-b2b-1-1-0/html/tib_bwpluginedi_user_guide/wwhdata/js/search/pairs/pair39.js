function FileData_Pairs(x)
{
x.t("appendix","parsing");
x.t("method","code");
x.t("hashmap","overview");
x.t("hashmap","keys");
x.t("implement","different");
x.t("business","logic");
x.t("callback","shared");
x.t("shows","sample");
x.t("sample","info");
x.t("parsing","data");
x.t("form","hashmap");
x.t("info","variable");
x.t("file","input");
x.t("overview","callback");
x.t("overview","overview");
x.t("overview","tibco");
x.t("parse","info");
x.t("flat","file");
x.t("provides","updateanalysis");
x.t("allows","modify");
x.t("updateanalysis","method");
x.t("resource","allows");
x.t("input","data");
x.t("logic","provides");
x.t("software","appendix");
x.t("different","business");
x.t("xml","format");
x.t("format","hashmap");
x.t("format","form");
x.t("format","tibco");
x.t("format","edi");
x.t("code","implement");
x.t("code","parse");
x.t("tibco","software");
x.t("java","code");
x.t("variable","value");
x.t("keys","values");
x.t("value","xml");
x.t("figure","shows");
x.t("figure","info");
x.t("data","flat");
x.t("data","xml");
x.t("data","figure");
x.t("shared","resource");
x.t("values","figure");
x.t("edi","input");
x.t("modify","java");
}
