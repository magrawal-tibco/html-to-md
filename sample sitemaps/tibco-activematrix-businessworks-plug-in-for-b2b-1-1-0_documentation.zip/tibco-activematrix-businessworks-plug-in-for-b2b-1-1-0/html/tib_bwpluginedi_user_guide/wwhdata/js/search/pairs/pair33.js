function FileData_Pairs(x)
{
x.t("example","figure");
x.t("appendix","electronic");
x.t("receiver","perform");
x.t("combinations","data");
x.t("functional","group");
x.t("business","transaction");
x.t("ensures","file");
x.t("required","receiver");
x.t("(se)","data");
x.t("various","combinations");
x.t("shows","x12");
x.t("line","document");
x.t("type","figure");
x.t("basic","units");
x.t("basic","unit");
x.t("enveloping","enveloping");
x.t("enveloping","edi");
x.t("details","figure");
x.t("single","line");
x.t("single","file");
x.t("document","data");
x.t("file","integrity");
x.t("file","several");
x.t("file","data");
x.t("file","contains");
x.t("lets","message");
x.t("list","contains");
x.t("group","group");
x.t("group","header");
x.t("group","similar");
x.t("group","starts");
x.t("group","trailer");
x.t("units","information");
x.t("ends","functional");
x.t("ends","interchange");
x.t("ends","transaction");
x.t("perform","standard");
x.t("(iea)","functional");
x.t("determine","destination");
x.t("(ge)","transaction");
x.t("standard","business");
x.t("destination","type");
x.t("segments","tibco");
x.t("segments","roughly");
x.t("segments","used");
x.t("integrity","lets");
x.t("sets","functions");
x.t("sets","data");
x.t("contain","basic");
x.t("functions","functional");
x.t("equivalent","single");
x.t("(gs)","ends");
x.t("unit","edi");
x.t("function","group");
x.t("software","appendix");
x.t("interchange","basic");
x.t("interchange","header");
x.t("interchange","structure");
x.t("interchange","starts");
x.t("interchange","trailer");
x.t("tibco","software");
x.t("known","enveloping");
x.t("message","determine");
x.t("header","(gs)");
x.t("header","(st)");
x.t("header","(isa)");
x.t("roughly","equivalent");
x.t("similar","transaction");
x.t("figure","shows");
x.t("figure","interchange");
x.t("figure","edi");
x.t("several","interchanges");
x.t("(st)","ends");
x.t("transfer","interchange");
x.t("data","segments");
x.t("data","interchange");
x.t("data","transfer");
x.t("data","elements");
x.t("information","required");
x.t("information","used");
x.t("structure","example");
x.t("structure","tibco");
x.t("structure","known");
x.t("structure","structure");
x.t("structure","following");
x.t("structure","edi");
x.t("bundled","single");
x.t("(isa)","ends");
x.t("transaction","sets");
x.t("transaction","header");
x.t("transaction","transaction");
x.t("transaction","starts");
x.t("transaction","trailer");
x.t("transaction","contains");
x.t("electronic","data");
x.t("following","list");
x.t("starts","function");
x.t("starts","interchange");
x.t("starts","transaction");
x.t("used","various");
x.t("used","transaction");
x.t("elements","contain");
x.t("edi","ensures");
x.t("edi","file");
x.t("edi","structure");
x.t("interchanges","bundled");
x.t("trailer","(se)");
x.t("trailer","(iea)");
x.t("trailer","(ge)");
x.t("contains","details");
x.t("contains","information");
x.t("contains","structure");
x.t("x12","edi");
}
