function FileData_Pairs(x)
{
x.t("supports","callback");
x.t("example","005010");
x.t("example","-ge-y");
x.t("example","0x1e");
x.t("example","100");
x.t("example","integer");
x.t("example","hex");
x.t("csv","generateresponse");
x.t("included","response");
x.t("/bin","directory");
x.t("svrty","record");
x.t("ds_rpt_valid_results","n/a");
x.t("protocols","supported");
x.t("protocols","following");
x.t("isa","version");
x.t("isa","enveloping");
x.t("appendix","instream");
x.t("appendix","acknowledgements");
x.t("appendix","electronic");
x.t("available","xml");
x.t("available","valid");
x.t("transactions","appendix");
x.t("transactions","generate");
x.t("exist","sure");
x.t("exist","-dav");
x.t("claim","data");
x.t("version","outbound");
x.t("version","numbers");
x.t("instream-translator","/bin");
x.t("rg_contrl_doc_","filename");
x.t("files","default");
x.t("files","document");
x.t("files","(ds_rpt_valid_filename)");
x.t("files","already");
x.t("files","generated");
x.t("files","(ds_rpt_invalid_filename)");
x.t("files","output");
x.t("files","appropriate");
x.t("files","containing");
x.t("functional","acknowledgement");
x.t("inbound","contrl");
x.t("full","path");
x.t("every","validation");
x.t("lists","exceptions");
x.t("create","responses");
x.t("create","profile");
x.t("table","instream");
x.t("description","description");
x.t("description","dialog");
x.t("description","document");
x.t("description","short");
x.t("description","name");
x.t("description","return_code");
x.t("description","activity");
x.t("description","validator_profile");
x.t("description","generate");
x.t("describes","errors");
x.t("tree","format");
x.t("rg_277_filename","string");
x.t("callback","check");
x.t("callback","resource");
x.t("callback","shareresource");
x.t("callback","checkbox");
x.t("callback","function");
x.t("callback","code");
x.t("callback","shared");
x.t("callback","resources");
x.t("997","functional");
x.t("997","check");
x.t("source","document");
x.t("summary","file");
x.t("summary","results");
x.t("summary","validation");
x.t("summary","xml");
x.t("apply","current");
x.t("guideline_name","string");
x.t("ds_rpt_invalid_filename","output");
x.t("rg_824_filename","string");
x.t("creates","two");
x.t("enabled","summary");
x.t("enabled","apf");
x.t("enabled","applicable");
x.t("enabled","guideline");
x.t("current","activity");
x.t("999","functional");
x.t("999","check");
x.t("999","implementation");
x.t("foresight","instream\u2019s");
x.t("instream\u2019s","doc");
x.t("shows","protocols");
x.t("shows","features");
x.t("uses","validation");
x.t("field","find");
x.t("field","msg_content");
x.t("field","appears");
x.t("field","displayed");
x.t("field","global");
x.t("field","note");
x.t("field","following");
x.t("dialog","input");
x.t("dialog","select");
x.t("dialog","usable");
x.t("fatal","count");
x.t("ds_report_content","string");
x.t("generating","acknowledgements");
x.t("support","protocols");
x.t("provided","instream");
x.t("mode","selected");
x.t("mode","specifies");
x.t("mode","configuration");
x.t("mode","run");
x.t("errors","severity");
x.t("errors","warnings");
x.t("displays","validation");
x.t("responses","support");
x.t("responses","277");
x.t("pdf","document");
x.t("ta1","check");
x.t("ta1","interchange");
x.t("open","select");
x.t("type","description");
x.t("type","drop-down");
x.t("response","uses");
x.t("response","file");
x.t("response","check");
x.t("response","functions");
x.t("response","documents");
x.t("response","generator");
x.t("enveloping","included");
x.t("enveloping","enveloping");
x.t("enveloping","ignored");
x.t("enveloping","note");
x.t("enveloping","incoming");
x.t("enveloping","edi");
x.t("time","validate");
x.t("time","number");
x.t("time","end");
x.t("input_file","string");
x.t("ds_rpt_valid_filename","output");
x.t("multiple","segments");
x.t("multiple","documents");
x.t("multiple","invalid");
x.t("multiple","valid");
x.t("277","acknowledgement");
x.t("277","check");
x.t("277","ca/u");
x.t("acknowledgement","rg_contrl_doc_");
x.t("acknowledgement","997");
x.t("acknowledgement","rg_824_filename");
x.t("acknowledgement","999");
x.t("acknowledgement","ta1");
x.t("acknowledgement","277");
x.t("acknowledgement","contrl");
x.t("acknowledgement","rg_999");
x.t("acknowledgement","rg_ta1");
x.t("acknowledgement","824");
x.t("acknowledgement","rg_contrl_doc");
x.t("acknowledgement","rg_999_filename");
x.t("acknowledgement","generated");
x.t("acknowledgement","rg_ta1_filename");
x.t("acknowledgement","rg_824");
x.t("formats","character");
x.t("total","errors");
x.t("ds_rpt_invalid_content","ds_rpt_invalid_content");
x.t("ds_rpt_invalid_content","output");
x.t("listed","appendix");
x.t("listed","dialog");
x.t("listed","response");
x.t("default","apf");
x.t("count","fatal");
x.t("count","number");
x.t("count","user1");
x.t("count","user2");
x.t("details","response");
x.t("details","document");
x.t("details","validation");
x.t("details","generate");
x.t("details","edi");
x.t("contrl","document");
x.t("contrl","parameters");
x.t("element","separator");
x.t("837","transactions");
x.t("precedence","input");
x.t("start","time");
x.t("thrown","activity");
x.t("thrown","indicating");
x.t("instream","callback");
x.t("instream","instream");
x.t("instream","generateresponse");
x.t("instream","input");
x.t("instream","validation");
x.t("instream","activity");
x.t("instream","tibco");
x.t("instream","configuration");
x.t("instream","documentsplitter");
x.t("instream","output");
x.t("instream","exceptions");
x.t("document","field");
x.t("document","response");
x.t("document","details");
x.t("document","contrl");
x.t("document","file");
x.t("document","changed");
x.t("document","total_of_error");
x.t("document","level");
x.t("document","tibco");
x.t("document","memory");
x.t("document","generated");
x.t("document","information");
x.t("document","splitter");
x.t("997/999","functional");
x.t("overwrite","files");
x.t("apf","file");
x.t("apf","$fsdeflt.apf");
x.t("severity","recorded");
x.t("severity","level");
x.t("fsinstreamexception","occurs");
x.t("list","files");
x.t("list","shows");
x.t("list","ds_rpt_invalid_content");
x.t("list","allows");
x.t("list","invalid");
x.t("list","ds_rpt_valid_content");
x.t("list","valid");
x.t("file","field");
x.t("file","mode");
x.t("file","precedence");
x.t("file","apf");
x.t("file","instream");
x.t("file","features");
x.t("file","flat");
x.t("file","extracted");
x.t("file","format");
x.t("file","xml");
x.t("file","memory");
x.t("file","output_directory");
x.t("file","read");
x.t("file","output");
x.t("file","note");
x.t("file","contains");
x.t("status","claim");
x.t("short","description");
x.t("indicates","isa");
x.t("indicates","group");
x.t("indicates","string");
x.t("outbound","-fver_pass");
x.t("need","specify");
x.t("ini","file");
x.t("found","during");
x.t("found","return");
x.t("add","description");
x.t("responding","hipaa");
x.t("responding","edifact");
x.t("responding","x12");
x.t("group","enveloping");
x.t("during","validation");
x.t("validate","apf");
x.t("validate","input");
x.t("validate","edi");
x.t("results","supports");
x.t("results","create");
x.t("results","summary");
x.t("results","file");
x.t("results","flat");
x.t("results","validation");
x.t("results","generate");
x.t("results","separate");
x.t("normally","efficient");
x.t("check","callback");
x.t("check","document");
x.t("check","checkbox");
x.t("splitting","edi");
x.t("flat","file");
x.t("features","provided");
x.t("features","following");
x.t("large","documents");
x.t("227","ca/u");
x.t("sure","move");
x.t("fails","generating");
x.t("fails","splitting");
x.t("fails","tibco");
x.t("specified","field");
x.t("specified","document");
x.t("name","997");
x.t("name","999");
x.t("name","ta1");
x.t("name","contrl");
x.t("name","document");
x.t("name","227");
x.t("name","name");
x.t("name","input");
x.t("name","validation");
x.t("name","activity");
x.t("name","824");
x.t("name","invalid");
x.t("name","valid");
x.t("name","guideline");
x.t("definition","description");
x.t("stored","files");
x.t("stored","two");
x.t("functionality","applicable");
x.t("path","name");
x.t("ran","successfully");
x.t("warnings","found");
x.t("warnings","messages");
x.t("manual","pdf");
x.t("005010","application");
x.t("-fver_pass","indicates");
x.t("changed","input");
x.t("follows","table");
x.t("codes","listed");
x.t("component","element");
x.t("avoid","error");
x.t("parameters","listed");
x.t("parameters","document");
x.t("parameters","specify");
x.t("-dav","string");
x.t("validation_summary","n/a");
x.t("provides","content");
x.t("profile","create");
x.t("profile","multiple");
x.t("profile","split");
x.t("find","document");
x.t("determine","checked");
x.t("rg_997","string");
x.t("allows","plug-in");
x.t("allows","specify");
x.t("fine","even");
x.t("generateresponse","generateresponse");
x.t("generateresponse","fields");
x.t("generateresponse","tab");
x.t("records","total");
x.t("validation_summary_in","_flatfile");
x.t("segments","response");
x.t("segments","ds_rpt_invalid_results");
x.t("segments","memory");
x.t("fields","table");
x.t("fields","field");
x.t("fields","input");
x.t("fields","output");
x.t("segment","terminator");
x.t("string","example");
x.t("string","field");
x.t("string","indicates");
x.t("string","name");
x.t("string","provides");
x.t("string","specifies");
x.t("string","(optional)");
x.t("133","means");
x.t("record","summary");
x.t("rg_999","string");
x.t("plug-in","validate");
x.t("input","mode");
x.t("input","document");
x.t("input","file");
x.t("input","fields");
x.t("input","input");
x.t("input","activity");
x.t("input","data");
x.t("input","edi");
x.t("input","tab");
x.t("input","item");
x.t("stream","detail");
x.t("resource","enabled");
x.t("resource","dialog");
x.t("resource","click");
x.t("three","options");
x.t("functions","enabled");
x.t("functions","fail");
x.t("selected","rg_277_filename");
x.t("selected","ds_report_content");
x.t("selected","input");
x.t("selected","validation_resultfile");
x.t("selected","rg_277");
x.t("selected","validation_result_in");
x.t("selected","output");
x.t("selected","ds_report_filename");
x.t("msg_content","string");
x.t("total_of_error","integer");
x.t("validation_resultfile","string");
x.t("supported","instream");
x.t("supported","node");
x.t("point","grouping");
x.t("documents","response");
x.t("documents","document");
x.t("documents","fails");
x.t("documents","stored");
x.t("return_code","integer");
x.t("error","count");
x.t("error","thrown");
x.t("error","error");
x.t("error","output");
x.t("rg_ta1","string");
x.t("validation","summary");
x.t("validation","creates");
x.t("validation","start");
x.t("validation","file");
x.t("validation","results");
x.t("validation","check");
x.t("validation","ran");
x.t("validation","avoid");
x.t("validation","checkbox");
x.t("validation","function");
x.t("validation","technical");
x.t("validation","validation_summaryfile");
x.t("validation","separator");
x.t("validation","except");
x.t("validation","used");
x.t("validation","including");
x.t("validation","detail");
x.t("checkbox","appendix");
x.t("checkbox","validate");
x.t("checkbox","enable");
x.t("checkbox","generate");
x.t("checkbox","separators");
x.t("checkbox","used");
x.t("checkbox","checked");
x.t("shareresource","field");
x.t("-ge-y","indicates");
x.t("ds_rpt_invalid_results","n/a");
x.t("occurs","validating");
x.t("split","point");
x.t("split","validation");
x.t("split","information");
x.t("split","based");
x.t("split","edi");
x.t("fail","configuration");
x.t("button","open");
x.t("button","add");
x.t("options","available");
x.t("options","file");
x.t("connecting","large");
x.t("appears","document");
x.t("appears","file");
x.t("appears","check");
x.t("appears","memory");
x.t("select","apply");
x.t("select","resource");
x.t("means","validation");
x.t("means","database");
x.t("recorded","svrty");
x.t("messages","memory");
x.t("messages","statistics");
x.t("rg_277","string");
x.t("activity","table");
x.t("activity","time");
x.t("activity","follows");
x.t("activity","allows");
x.t("activity","validation");
x.t("activity","twice");
x.t("activity","click");
x.t("activity","documentsplitter");
x.t("activity","process");
x.t("activity","x12");
x.t("terminator","element");
x.t("0x1d","callback");
x.t("control","check");
x.t("written","output");
x.t("number","errors");
x.t("rg_997_filename","string");
x.t("cause","fsinstreamexception");
x.t("function","callback");
x.t("function","instream");
x.t("function","document");
x.t("function","overwrite");
x.t("function","validation");
x.t("function","report");
x.t("function","works");
x.t("function","generate");
x.t("0x1e","0x1f");
x.t("indicating","output");
x.t("software","chapter");
x.t("chapter","b2b");
x.t("hipaa","837");
x.t("hipaa","edifact");
x.t("specifies","full");
x.t("specifies","apf");
x.t("specifies","input");
x.t("specifies","return");
x.t("specifies","message");
x.t("specifies","output");
x.t("specifies","content");
x.t("0x1f","0x1d");
x.t("cannot","found");
x.t("move","output");
x.t("edifact","flat");
x.t("edifact","validation");
x.t("report","ds_rpt_valid_results");
x.t("report","type");
x.t("report","types");
x.t("report","format");
x.t("report","following");
x.t("report","containing");
x.t("report","contains");
x.t("ignored","check");
x.t("extracted","callback");
x.t("twice","using");
x.t("types","generated");
x.t("format","validation_summary");
x.t("format","validation_summary_in");
x.t("format","supported");
x.t("format","drop-down");
x.t("format","generated");
x.t("format","note");
x.t("format","contains");
x.t("xml","csv");
x.t("xml","tree");
x.t("xml","format");
x.t("directory","cannot");
x.t("directory","output");
x.t("directory","note");
x.t("filename","string");
x.t("824","check");
x.t("824","application");
x.t("works","fine");
x.t("node","displays");
x.t("node","disappear");
x.t("technical","manual");
x.t("invalid","files");
x.t("invalid","multiple");
x.t("invalid","report");
x.t("invalid","data");
x.t("invalid","edi");
x.t("invalid","generates");
x.t("enable","callback");
x.t("enable","response");
x.t("enable","document");
x.t("code","example");
x.t("code","guideline_name");
x.t("code","ds_profile");
x.t("end","time");
x.t("rg_contrl_doc","string");
x.t("interchange","acknowledgement");
x.t("interchange","details");
x.t("level","error");
x.t("level","validation");
x.t("level","larger");
x.t("folder","example");
x.t("located","tibco_foresight_home");
x.t("return","codes");
x.t("return","code");
x.t("validation_summaryfile","string");
x.t("(ds_rpt_valid_filename)","ds_rpt_valid_filename");
x.t("tibco","foresight");
x.t("tibco","software");
x.t("memory","mode");
x.t("memory","normally");
x.t("memory","memory");
x.t("memory","output");
x.t("output_directory","string");
x.t("100","means");
x.t("successfully","133");
x.t("database","directory");
x.t("message","validation");
x.t("click","button");
x.t("validator_profile","string");
x.t("n/a","node");
x.t("n/a","contains");
x.t("(optional)","field");
x.t("(optional)","specifies");
x.t("displayed","callback");
x.t("validation_result_in","_flatfile");
x.t("rg_999_filename","string");
x.t("advice","997/999");
x.t("advice","rg_997");
x.t("advice","rg_997_filename");
x.t("advice","824");
x.t("advice","generated");
x.t("configuration","fields");
x.t("configuration","configuration");
x.t("configuration","panel");
x.t("configuration","information");
x.t("configuration","tab");
x.t("usable","instream");
x.t("disappear","docsplitter");
x.t("ds_rpt_valid_content","ds_rpt_valid_content");
x.t("ds_rpt_valid_content","output");
x.t("b2b","palette");
x.t("documentsplitter","fields");
x.t("documentsplitter","documentsplitter");
x.t("documentsplitter","tab");
x.t("drop-down","list");
x.t("already","exist");
x.t("implementation","acknowledgement");
x.t("generate","997");
x.t("generate","999");
x.t("generate","responses");
x.t("generate","ta1");
x.t("generate","response");
x.t("generate","277");
x.t("generate","contrl");
x.t("generate","control");
x.t("generate","824");
x.t("generator","functions");
x.t("generator","function");
x.t("generator","technical");
x.t("process","instream");
x.t("process","definition");
x.t("generated","responding");
x.t("generated","input");
x.t("generated","report");
x.t("generated","following");
x.t("acknowledgements","details");
x.t("acknowledgements","fails");
x.t("(ds_rpt_invalid_filename)","ds_rpt_invalid_filename");
x.t("exception","cause");
x.t("valid","files");
x.t("valid","invalid");
x.t("valid","data");
x.t("valid","edi");
x.t("separators","segment");
x.t("ca/u","acknowledgement");
x.t("read","determine");
x.t("panel","need");
x.t("output","files");
x.t("output","mode");
x.t("output","fields");
x.t("output","stream");
x.t("output","error");
x.t("output","activity");
x.t("output","specifies");
x.t("output","directory");
x.t("output","output");
x.t("output","location");
x.t("output","data");
x.t("output","tab");
x.t("output","item");
x.t("separate","valid");
x.t("applicable","callback");
x.t("applicable","x12");
x.t("larger","level");
x.t("docsplitter","file");
x.t("location","every");
x.t("location","error");
x.t("data","type");
x.t("data","enveloping");
x.t("data","document");
x.t("data","list");
x.t("data","fails");
x.t("data","stored");
x.t("data","split");
x.t("data","interchange");
x.t("data","note");
x.t("data","contains");
x.t("information","ds_rpt_valid_results");
x.t("information","instream");
x.t("information","validation");
x.t("doc","folder");
x.t("_flatfile","string");
x.t("ds_report_filename","string");
x.t("shared","resource");
x.t("tibco_foresight_home","instream-translator");
x.t("ds_profile","string");
x.t("appropriate","location");
x.t("validating","input");
x.t("application","version");
x.t("application","advice");
x.t("locate","instream");
x.t("user1","count");
x.t("global","var");
x.t("efficient","connecting");
x.t("character","example");
x.t("user2","count");
x.t("two","files");
x.t("two","options");
x.t("note","field");
x.t("note","document");
x.t("note","splitting");
x.t("note","functionality");
x.t("note","parameters");
x.t("protocol","document");
x.t("integer","example");
x.t("integer","records");
x.t("integer","specifies");
x.t("based","split");
x.t("incoming","edi");
x.t("electronic","data");
x.t("order","specified");
x.t("numbers","source");
x.t("following","formats");
x.t("following","list");
x.t("following","fields");
x.t("following","three");
x.t("following","two");
x.t("separator","field");
x.t("separator","component");
x.t("separator","order");
x.t("hex","example");
x.t("used","input");
x.t("used","validation");
x.t("used","locate");
x.t("except","inbound");
x.t("$fsdeflt.apf","located");
x.t("run","process");
x.t("edi","isa");
x.t("edi","transactions");
x.t("edi","enveloping");
x.t("edi","multiple");
x.t("edi","file");
x.t("edi","invalid");
x.t("edi","valid");
x.t("edi","data");
x.t("edi","based");
x.t("containing","status");
x.t("containing","invalid");
x.t("containing","valid");
x.t("guideline","extracted");
x.t("guideline","used");
x.t("general","messages");
x.t("rg_ta1_filename","string");
x.t("rg_824","string");
x.t("using","input");
x.t("grouping","specified");
x.t("tab","lists");
x.t("tab","input_file");
x.t("tab","need");
x.t("tab","documentsplitter");
x.t("tab","contains");
x.t("statistics","describes");
x.t("var","description");
x.t("including","validation");
x.t("generates","list");
x.t("even","document");
x.t("exceptions","thrown");
x.t("exceptions","exception");
x.t("palette","instream");
x.t("detail","results");
x.t("x12","hipaa");
x.t("x12","protocol");
x.t("x12","edi");
x.t("splitter","uses");
x.t("splitter","response");
x.t("splitter","ini");
x.t("splitter","check");
x.t("splitter","profile");
x.t("splitter","checkbox");
x.t("splitter","function");
x.t("splitter","report");
x.t("splitter","technical");
x.t("splitter","generate");
x.t("splitter","note");
x.t("contains","isa");
x.t("contains","summary");
x.t("contains","multiple");
x.t("contains","status");
x.t("contains","list");
x.t("contains","configuration");
x.t("contains","following");
x.t("contains","general");
x.t("resources","listed");
x.t("specify","full");
x.t("specify","parameters");
x.t("specify","report");
x.t("specify","format");
x.t("specify","output");
x.t("specify","content");
x.t("item","data");
x.t("checked","written");
x.t("checked","documentsplitter");
x.t("content","997");
x.t("content","999");
x.t("content","ta1");
x.t("content","277");
x.t("content","contrl");
x.t("content","document");
x.t("content","input");
x.t("content","824");
x.t("content","invalid");
x.t("content","valid");
}
