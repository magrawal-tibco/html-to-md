function FileData_Pairs(x)
{
x.t("example","flattoflat");
x.t("example","name");
x.t("example","partnerautomationflat=");
x.t("csv","file");
x.t("included","project");
x.t("provide","data");
x.t("method","implement");
x.t("method","covers");
x.t("method","details");
x.t("method","java");
x.t("method","called");
x.t("flattoflat","flattoxml");
x.t("c:\\bwprojects\\edi\\data\\sampleflatfilepartnerautomation5.csv","$dir.ini");
x.t("library","allows");
x.t("properties","section");
x.t("version","3.2");
x.t("version","3.2.1");
x.t("needs","compilation");
x.t("needs","update");
x.t("needs","updated");
x.t("files","updatemessagewithcallback");
x.t("files","need");
x.t("files","tibco");
x.t("files","memory");
x.t("files","java");
x.t("files","based");
x.t("comment","global");
x.t("implement","business");
x.t("functional","groups");
x.t("table","translator");
x.t("description","description");
x.t("description","dialog");
x.t("description","short");
x.t("description","name");
x.t("description","activity");
x.t("description","java");
x.t("business","logic");
x.t("refer","fsjtransapimsg");
x.t("callback","checkbox");
x.t("callback","function");
x.t("callback","advantage");
x.t("callback","types");
x.t("callback","code");
x.t("callback","tibco");
x.t("callback","translator");
x.t("callback","configuration");
x.t("callback","shared");
x.t("eight","callback");
x.t("eight","types");
x.t("variables","accessed");
x.t("variables","java");
x.t("source","code");
x.t("once","map");
x.t("alias","library");
x.t("covers","eight");
x.t("foresight","translator");
x.t("current","source");
x.t("fsaskval","fsstartdoc");
x.t("implemented","based");
x.t("field","source");
x.t("field","global");
x.t("field","modify");
x.t("dialog","alias");
x.t("dialog","appear");
x.t("uses","aliaslibrary");
x.t("locations","jar");
x.t("updatemessagewithcallback","int");
x.t("support","callback");
x.t("support","switching");
x.t("icon","appears");
x.t("errors","dialog");
x.t("errors","button");
x.t("errors","code");
x.t("errors","encountered");
x.t("displays","source");
x.t("displays","errors");
x.t("html","file");
x.t("type","string");
x.t("type","xml");
x.t("whenever","map");
x.t("whenever","tibco");
x.t("formats","example");
x.t("compiles","current");
x.t("yellow","warning");
x.t("multiple","interchanges");
x.t("property","$dir.ini");
x.t("$dir.ini","configuration");
x.t("needed","translator");
x.t("needed","value");
x.t("default","method");
x.t("engine","needs");
x.t("details","callback");
x.t("details","aliaslibrary");
x.t("details","code");
x.t("translate","flat");
x.t("element","description");
x.t("aliaslibrary","resource");
x.t("file","example");
x.t("file","needed");
x.t("file","need");
x.t("file","flat");
x.t("file","updating");
x.t("file","input");
x.t("file","located");
x.t("file","selectmap");
x.t("file","translation");
x.t("file","tib_translator_home");
x.t("flattoedi","need");
x.t("need","included");
x.t("need","add");
x.t("need","value");
x.t("short","description");
x.t("add","description");
x.t("add","partnerautomationflat");
x.t("jar","files");
x.t("callback_x12-1","package");
x.t("api","enable");
x.t("check","callback");
x.t("guide","details");
x.t("version_number","\\java\\docs\\com\\foresight\\jtransapi");
x.t("3.2","support");
x.t("flat","file");
x.t("fsdata","selectmap");
x.t("guidelines","map");
x.t("operation","type");
x.t("name","example");
x.t("name","name");
x.t("name","activity");
x.t("name","translator");
x.t("definition","description");
x.t("changed","callback_x121");
x.t("edit","class");
x.t("fsenddoc","fsdata");
x.t("custom","guidelines");
x.t("bytes","update");
x.t("updating","namestring");
x.t("namestring","variable");
x.t("partnerautomationflat=","c:\\bwprojects\\edi\\data\\sampleflatfilepartnerautomation5.csv");
x.t("standard","java");
x.t("fsstartdoc","fsenddoc");
x.t("map","files");
x.t("map","file");
x.t("allows","specify");
x.t("modifying","updatemessagewithcallback");
x.t("int","type");
x.t("string","value");
x.t("fields","table");
x.t("fields","field");
x.t("accessed","translator");
x.t("resource","implemented");
x.t("resource","callback_x12-1");
x.t("resource","check");
x.t("resource","name");
x.t("resource","implements");
x.t("resource","code");
x.t("resource","called");
x.t("resource","general");
x.t("input","message");
x.t("input","data");
x.t("switching","map");
x.t("designer","uses");
x.t("designer","user\u2019s");
x.t("display","errors");
x.t("logic","modifying");
x.t("checkbox","translator");
x.t("respectively","code");
x.t("select","guidelines");
x.t("button","displays");
x.t("button","compiles");
x.t("button","add");
x.t("button","code");
x.t("appears","button");
x.t("activity","needs");
x.t("activity","tibco");
x.t("activity","click");
x.t("activity","configuration");
x.t("activity","process");
x.t("gui","element");
x.t("gui","elements");
x.t("function","operation");
x.t("function","shared");
x.t("implements","eight");
x.t("comments","say");
x.t("software","chapter");
x.t("chapter","b2b");
x.t("advantage","types");
x.t("editor","updatemessagewithcallback");
x.t("fserror","fsupdate");
x.t("callback_x121","respectively");
x.t("callback_x121","callback_x121");
x.t("accessing","tibco");
x.t("types","provide");
x.t("types","callback");
x.t("types","enable");
x.t("types","tibco");
x.t("types","fsversion");
x.t("xml","flat");
x.t("xml","edi");
x.t("section","tibco");
x.t("compile","button");
x.t("compile","successfully");
x.t("directory","information");
x.t("enable","translator");
x.t("code","method");
x.t("code","field");
x.t("code","activity");
x.t("code","editor");
x.t("code","accessing");
x.t("code","compile");
x.t("code","code");
x.t("code","java");
x.t("code","named");
x.t("code","view");
x.t("code","shared");
x.t("code","package");
x.t("code","either");
x.t("code","tab");
x.t("code","compiled");
x.t("reference","details");
x.t("located","tib_translator_home");
x.t("folder","configuration");
x.t("fsjtransapimsg","html");
x.t("groups","input");
x.t("tibco","foresight");
x.t("tibco","designer");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("successfully","view");
x.t("appear","display");
x.t("memory","bytes");
x.t("message","file");
x.t("translator","version");
x.t("translator","callback");
x.t("translator","engine");
x.t("translator","activity");
x.t("translator","java");
x.t("java","api");
x.t("java","code");
x.t("java","system");
x.t("java","class");
x.t("java","naming");
x.t("click","button");
x.t("variable","refer");
x.t("project","tibco");
x.t("configuration","file");
x.t("configuration","fields");
x.t("configuration","configuration");
x.t("configuration","tab");
x.t("partnerautomationflat","csv");
x.t("partnerautomationflat","property");
x.t("value","method");
x.t("value","needs");
x.t("value","partnerautomationflat");
x.t("bin","folder");
x.t("named","using");
x.t("activematrix","businessworks");
x.t("b2b","palette");
x.t("process","definition");
x.t("compilation","yellow");
x.t("view","errors");
x.t("third-party","jar");
x.t("encountered","code");
x.t("data","formats");
x.t("data","custom");
x.t("data","select");
x.t("data","load");
x.t("information","callback");
x.t("3.2.1","support");
x.t("shared","resource");
x.t("case","called");
x.t("called","once");
x.t("called","whenever");
x.t("global","variables");
x.t("global","var");
x.t("based","multiple");
x.t("based","tibco");
x.t("based","translator");
x.t("package","class");
x.t("fsupdate","fsaskval");
x.t("following","fields");
x.t("following","gui");
x.t("say","modify");
x.t("system","properties");
x.t("elements","table");
x.t("either","compile");
x.t("\\java\\docs\\com\\foresight\\jtransapi","directory");
x.t("edi","xml");
x.t("general","palette");
x.t("class","button");
x.t("class","names");
x.t("class","specify");
x.t("using","standard");
x.t("businessworks","global");
x.t("businessworks","palette");
x.t("warning","icon");
x.t("selectmap","advantage");
x.t("selectmap","case");
x.t("tab","gui");
x.t("tab","tibco");
x.t("tab","java");
x.t("tab","contains");
x.t("translation","translate");
x.t("translation","java");
x.t("flattoxml","flattoedi");
x.t("interchanges","functional");
x.t("tib_translator_home","version_number");
x.t("tib_translator_home","bin");
x.t("names","changed");
x.t("names","java");
x.t("modify","comment");
x.t("modify","content");
x.t("load","custom");
x.t("var","description");
x.t("compiled","edit");
x.t("naming","conventions");
x.t("conventions","based");
x.t("palette","reference");
x.t("palette","translator");
x.t("palette","specify");
x.t("update","map");
x.t("update","data");
x.t("contains","following");
x.t("specify","locations");
x.t("specify","map");
x.t("specify","third-party");
x.t("user\u2019s","guide");
x.t("content","comments");
x.t("updated","default");
x.t("fsversion","fserror");
}
