function  WWHBookData_AddTOCEntries(P)
{
var A=P.fN("Figures","2");
A=P.fN("Tables","3");
A=P.fN("Preface","4");
var B=A.fN("Related Documentation","5");
var C=B.fN("TIBCO ActiveMatrix BusinessWorks Plug-in for B2B Documentation","5#41264");
C=B.fN("Other TIBCO Product Documentation","5#24887");
B=A.fN("Typographical Conventions","6");
B=A.fN("Connecting with TIBCO Resources","7");
C=B.fN("How to Join TIBCOmmunity","7#39327");
C=B.fN("How to Access TIBCO Documentation","7#41109");
C=B.fN("How to Contact TIBCO Support","7#39302");
A=P.fN("Chapter\u00a01 Introduction","8");
B=A.fN("TIBCO Foresight Overview","9");
C=B.fN("Transaction Validation","9#1741899");
C=B.fN("Translation","9#1741919");
B=A.fN("TIBCO ActiveMatrix BusinessWorks Plug-in for B2B Overview","10");
A=P.fN("Chapter\u00a02 Getting Started","11");
B=A.fN("Overview","12");
B=A.fN("Creating a Project","13");
B=A.fN("Creating a Process","14");
B=A.fN("Adding Activities to a Process","15");
B=A.fN("Testing a Process","16");
B=A.fN("Deploying a Project","17");
B=A.fN("Defining Global Variables","18");
A=P.fN("Chapter\u00a03 B2B Palette","19");
B=A.fN("B2B Palette Overview","20");
B=A.fN("Instream CallBack","21");
C=B.fN("Configuration","21#1791002");
C=B.fN("Code","21#1791426");
B=A.fN("Translator CallBack","22");
C=B.fN("Configuration","22#1850022");
C=B.fN("Code","22#1867556");
B=A.fN("Instream","23");
C=B.fN("Configuration","23#1845760");
C=B.fN("DocumentSplitter","23#1746443");
C=B.fN("GenerateResponse","23#1742311");
C=B.fN("Input","23#1742400");
C=B.fN("Output","23#1869156");
C=B.fN("Error Output","23#1869416");
B=A.fN("Translator","24");
C=B.fN("Configuration","24#1742773");
C=B.fN("Input","24#1853321");
C=B.fN("Output","24#1854222");
C=B.fN("Error Output","24#1742977");
A=P.fN("Chapter\u00a04 Using the Sample Projects","25");
B=A.fN("Overview","26");
B=A.fN("Setting Up a Sample Project","27");
B=A.fN("BWB2B Sample Project","28");
C=B.fN("Instream-Translator Process","28#1857327");
C=B.fN("InstreamWithCallBack Process","28#1773633");
B=A.fN("Translator with CallBack Sample Project","29");
C=B.fN("TranslatorWithCallBack Process","29#1842954");
B=A.fN("Deploying a Sample Project","30");
A=P.fN("Appendix\u00a0A Electronic Data Interchange","31");
B=A.fN("Overview","32");
B=A.fN("Structure","33");
B=A.fN("Standards","34");
A=P.fN("Appendix\u00a0B Acknowledgements","35");
B=A.fN("Overview","36");
B=A.fN("Acknowledgements","37");
C=B.fN("227CA/U Acknowledgements","37#1744946");
C=B.fN("824 Application Advice","37#1756652");
C=B.fN("997 Functional Acknowledgement","37#1744824");
C=B.fN("999 Implementation Acknowledgement","37#1763865");
C=B.fN("TA1 Interchange Acknowledgement","37#1745146");
C=B.fN("CONTRL Document (EDIFACT Responses)","37#1743749");
A=P.fN("Appendix\u00a0C Parsing Data from XML Format to Hashmap","38");
B=A.fN("Overview","39");
B=A.fN("Parsing from XML to Hashmap","40");
A=P.fN("Appendix\u00a0D Error Codes","41");
B=A.fN("Error Codes","42");
}
