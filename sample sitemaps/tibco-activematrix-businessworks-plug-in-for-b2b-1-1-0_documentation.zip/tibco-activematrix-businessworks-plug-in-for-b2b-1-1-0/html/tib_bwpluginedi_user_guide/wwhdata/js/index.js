function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("A",null,null,"002");
var B=A.fA("APF file",new Array("23#1742432"));
A=P.fA("C",null,null,"002");
B=A.fA("CallBack shared resource",new Array("21#1812751"));
B=A.fA("CallBack type",new Array("22#1850131"));
B=A.fA("CallBackBuffer",new Array("24#1808624"));
B=A.fA("Create a new global variable",new Array("18#1823278"));
B=A.fA("customer support",new Array("7#39302"));
A=P.fA("D",null,null,"002");
B=A.fA("Document Level Validation",new Array("23#1746389"));
B=A.fA("Document Level Validation Separator",new Array("23#1808980"));
B=A.fA("Document Splitter",new Array("23#1755982","23#1755982"));
B=A.fA("DocumentSplitter",new Array("23#1746443"));
B=A.fA("DS Profile",new Array("23#1742444"));
A=P.fA("E",null,null,"002");
B=A.fA("EAR",new Array("30#1839143"));
B=A.fA("EDI",new Array("31"));
B=A.fA("EDI protocols",new Array("34#1743710"));
B=A.fA("EDI standards",new Array("34#1743710"));
B=A.fA("EDIFACT",new Array("34#1743716"));
B=A.fA("Electronic Data Interchange",new Array("31"));
B=A.fA("Enterprise Archive file",new Array("30#1839143"));
B=A.fA("Enveloping",new Array("33#1743689"));
A=P.fA("F",null,null,"002");
B=A.fA("Flat File",new Array("34#1743718"));
B=A.fA("Flat File translation",new Array("22#1865061"));
A=P.fA("G",null,null,"002");
B=A.fA("GenerateResponse",new Array("23#1742311"));
A=P.fA("H",null,null,"002");
B=A.fA("HIPAA",new Array("34#1763777"));
A=P.fA("I",null,null,"002");
B=A.fA("input encoding",new Array("24#1853363"));
B=A.fA("Instream activity",new Array("23#1819778"));
A=P.fA("M",null,null,"002");
B=A.fA("Map file",new Array("24#1853337"));
A=P.fA("O",null,null,"002");
B=A.fA("operation type",new Array("24#1853542"));
B=A.fA("output encoding",new Array("24#1853371"));
A=P.fA("R",null,null,"002");
B=A.fA("Response Generation",new Array("23#1845743"));
A=P.fA("S",null,null,"002");
B=A.fA("Separator Group",new Array("24#1808632"));
B=A.fA("support, contacting",new Array("7#39302"));
A=P.fA("T",null,null,"002");
B=A.fA("technical support",new Array("7#39302"));
B=A.fA("TIBCO ActiveMatrix BusinessWorks",new Array("12#1823156"));
B=A.fA("TIBCO Designer",new Array("12#1823156"));
B=A.fA("TIBCO Foresight",new Array("9"));
B=A.fA("TIBCO Foresight Instream",new Array("9#1741901"));
B=A.fA("TIBCO Foresight Translator",new Array("9#1741921"));
B=A.fA("TIBCO_HOME",new Array("6#41471"));
B=A.fA("Translation",new Array("9#1741919"));
B=A.fA("Translator activity",new Array("24#1742725"));
A=P.fA("V",null,null,"002");
B=A.fA("Validation",new Array("9#1741899","23#1742109"));
B=A.fA("Validator profile",new Array("23#1742428"));
A=P.fA("X",null,null,"002");
B=A.fA("X12",new Array("34#1743712"));
B=A.fA("XML",new Array("34#1743720"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 2;
}
