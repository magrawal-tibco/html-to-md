function  WWHBookData_Files(P)
{
P.fA("TIBCO ActiveMatrix BusinessWorks\u2122 Plug-in for B2B","title.1.1.htm");
P.fA("Important Information","copyrigh.htm");
P.fA("Figures","LOF.htm");
P.fA("Tables","LOT.htm");
P.fA("Preface","preface.4.1.htm");
P.fA("Related Documentation","preface.4.2.htm");
P.fA("Typographical Conventions","preface.4.3.htm");
P.fA("Connecting with TIBCO Resources","preface.4.4.htm");
P.fA("Introduction","usr.5.01.htm");
P.fA("TIBCO Foresight Overview","usr.5.02.htm");
P.fA("TIBCO ActiveMatrix BusinessWorks Plug-in for B2B Overview","usr.5.03.htm");
P.fA("Getting Started","usr.5.04.htm");
P.fA("Overview","usr.5.05.htm");
P.fA("Creating a Project","usr.5.06.htm");
P.fA("Creating a Process","usr.5.07.htm");
P.fA("Adding Activities to a Process","usr.5.08.htm");
P.fA("Testing a Process","usr.5.09.htm");
P.fA("Deploying a Project","usr.5.10.htm");
P.fA("Defining Global Variables","usr.5.11.htm");
P.fA("B2B Palette","usr.5.12.htm");
P.fA("B2B Palette Overview","usr.5.13.htm");
P.fA("Instream CallBack","usr.5.14.htm");
P.fA("Translator CallBack","usr.5.15.htm");
P.fA("Instream","usr.5.16.htm");
P.fA("Translator","usr.5.17.htm");
P.fA("Using the Sample Projects","usr.5.18.htm");
P.fA("Overview","usr.5.19.htm");
P.fA("Setting Up a Sample Project","usr.5.20.htm");
P.fA("BWB2B Sample Project","usr.5.21.htm");
P.fA("Translator with CallBack Sample Project","usr.5.22.htm");
P.fA("Deploying a Sample Project","usr.5.23.htm");
P.fA("Electronic Data Interchange","usr.5.24.htm");
P.fA("Overview","usr.5.25.htm");
P.fA("Structure","usr.5.26.htm");
P.fA("Standards","usr.5.27.htm");
P.fA("Acknowledgements","usr.5.28.htm");
P.fA("Overview","usr.5.29.htm");
P.fA("Acknowledgements","usr.5.30.htm");
P.fA("Parsing Data from XML Format to Hashmap","usr.5.31.htm");
P.fA("Overview","usr.5.32.htm");
P.fA("Parsing from XML to Hashmap","usr.5.33.htm");
P.fA("Error Codes","usr.5.34.htm");
P.fA("Error Codes","usr.5.35.htm");
}
