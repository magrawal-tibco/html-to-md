function  WWHBookData_MatchTopic(P)
{
var C=null;
if(P=="ae.palette.fs.helpurl")C="usr.5.13.htm";
if(P=="fs.javapalette.InstreamCallback.helpurl")C="usr.5.14.htm";
if(P=="fs.javapalette.TranslatorCallback.helpurl")C="usr.5.15.htm";
if(P=="fs.activities.instream.helpurl")C="usr.5.16.htm";
if(P=="fs.activities.translator.helpurl")C="usr.5.17.htm";
return C;
}
