function  WWHBookData_AddIndexEntries(P)
{
var A=P.fA("C",null,null,"002");
var B=A.fA("console mode",new Array("7#1694188"));
B=A.fA("customer support",new Array("5#39302"));
A=P.fA("G",null,null,"002");
B=A.fA("GUI mode",new Array("7#1694185"));
A=P.fA("I",null,null,"002");
B=A.fA("installation components",new Array("7#1694306"));
B=A.fA("installation modes");
var C=B.fA("console mode",new Array("7#1694188"));
C=B.fA("GUI mode",new Array("7#1694185"));
C=B.fA("silent mode",new Array("7#1694191"));
B=A.fA("installation procedure");
C=B.fA("Console mode",new Array("10#1680093"));
C=B.fA("GUI mode",new Array("10#1697373"));
C=B.fA("Silent mode",new Array("10#1696918"));
B=A.fA("installation profile");
C=B.fA("custom",new Array("7#1694264"));
C=B.fA("typical",new Array("7#1694225"));
B=A.fA("installation requirements");
C=B.fA("disk space requirements",new Array("8#1694392"));
C=B.fA("software requirements",new Array("8#1680504"));
C=B.fA("supported platforms",new Array("8#1680734"));
C=B.fA("system memory requirements",new Array("8#1694410"));
B=A.fA("installer account",new Array("7#1694266"));
B=A.fA("installer log file",new Array("7#1673871"));
A=P.fA("S",null,null,"002");
B=A.fA("Silent mode",new Array("7#1694191"));
B=A.fA("support, contacting",new Array("5#39302"));
A=P.fA("T",null,null,"002");
B=A.fA("technical support",new Array("5#39302"));
B=A.fA("TIBCO Foresight Instream",new Array("8#1680560"));
B=A.fA("TIBCO Foresight Translator",new Array("8#1680564"));
B=A.fA("TIBCO_HOME",new Array("4#42521"));
A=P.fA("U",null,null,"002");
B=A.fA("uninstallation procedure",new Array("11"));
}

function  WWHBookData_MaxIndexLevel()
{
  return 3;
}
