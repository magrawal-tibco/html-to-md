function FileData_Pairs(x)
{
x.t("example","mycommand");
x.t("example","parameter");
x.t("example","apply");
x.t("example","type");
x.t("example","portal");
x.t("example","esc");
x.t("example","tibco");
x.t("example","windows");
x.t("example","additional");
x.t("example","ctrl");
x.t("example","data");
x.t("c:\\tibco\\translator\\","version");
x.t("properties","name");
x.t("mycommand","enabled");
x.t("mycommand","start");
x.t("mycommand","pathname");
x.t("mycommand","enable");
x.t("parameter","command");
x.t("parameter","specified");
x.t("introduce","new");
x.t("version","code");
x.t("version","tibco");
x.t("combinations","key");
x.t("simultaneously","example");
x.t("within","tibco_home");
x.t("table","general");
x.t("installed","different");
x.t("installed","directory");
x.t("installed","folder");
x.t("installed","installation");
x.t("situation","example");
x.t("key","combinations");
x.t("key","names");
x.t("required","certain");
x.t("components","installation");
x.t("microsoft","windows");
x.t("c:\\tibco","tibco");
x.t("parts","sample");
x.t("action","required");
x.t("apply","information");
x.t("referenced","documentation");
x.t("foresight","instream");
x.t("foresight","translator");
x.t("user","types");
x.t("enabled","mycommand");
x.t("current","section");
x.t("icon","indicates");
x.t("provided","current");
x.t("type","admin");
x.t("sample","particular");
x.t("multiple","instances");
x.t("filenames","pathnames");
x.t("product","installed");
x.t("product","shortcut");
x.t("default","parameter");
x.t("default","value");
x.t("comma","space");
x.t("access","components");
x.t("consists","following");
x.t("start","programs");
x.t("start","foo");
x.t("new","terms");
x.t("certain","circumstances");
x.t("certain","steps");
x.t("instream","installed");
x.t("command","example");
x.t("command","window");
x.t("command","syntax");
x.t("command","code");
x.t("document","title");
x.t("indicates","potential");
x.t("indicates","idea");
x.t("indicates","information");
x.t("tibco_home","depends");
x.t("tibco_home","directory");
x.t("tibco_home","tib_b2b_home");
x.t("tibco_home","value");
x.t("menu","path");
x.t("installer","component");
x.t("depends","operating");
x.t("large","code");
x.t("products","installed");
x.t("products","multiple");
x.t("specified","mycommand");
x.t("circumstances","tip");
x.t("potential","damaging");
x.t("name","referenced");
x.t("name","appended");
x.t("name","identifies");
x.t("name","windows");
x.t("path","product");
x.t("path","folder");
x.t("manual","table");
x.t("component","path");
x.t("c:\\tibco\\bw\\plugins\\b2b","tibco");
x.t("shortcut","windows");
x.t("window","example");
x.t("plus","sign");
x.t("useful","example");
x.t("appended","name");
x.t("indicate","parts");
x.t("indicate","user");
x.t("indicate","default");
x.t("indicate","document");
x.t("indicate","variable");
x.t("indicate","keys");
x.t("sign","indicate");
x.t("preface","typographical");
x.t("pathname","key");
x.t("incompatible","products");
x.t("programs","menu");
x.t("plug-in","b2b");
x.t("procedures","indicate");
x.t("contain","several");
x.t("commands","code");
x.t("portal","indicate");
x.t("portal","page");
x.t("pressed","example");
x.t("pressed","simultaneously");
x.t("syntax","indicate");
x.t("syntax","replace");
x.t("esc","ctrl");
x.t("environments","incompatible");
x.t("environments","installation");
x.t("space","indicate");
x.t("software","preface");
x.t("different","installation");
x.t("particular","interest");
x.t("may","contain");
x.t("idea","useful");
x.t("ways","indicate");
x.t("ways","procedures");
x.t("replace","example");
x.t("directory","within");
x.t("directory","referenced");
x.t("directory","directory");
x.t("types","example");
x.t("admin","large");
x.t("samples","indicate");
x.t("section","achieve");
x.t("achieve","specific");
x.t("loss","corruption");
x.t("interest","command");
x.t("interest","importance");
x.t("code","syntax");
x.t("code","samples");
x.t("code","examples");
x.t("code","font");
x.t("enable","disable");
x.t("steps","taken");
x.t("tib_b2b_home","default");
x.t("tib_b2b_home","depends");
x.t("tib_b2b_home","tib_instream_home");
x.t("identifies","commands");
x.t("identifies","installation");
x.t("folder","referenced");
x.t("folder","product");
x.t("tibco","foresight");
x.t("tibco","products");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("environment","product");
x.t("environment","access");
x.t("environment","consists");
x.t("environment","name");
x.t("operating","system");
x.t("c:\\tibco\\instream\\","version");
x.t("documentation","tibco_home");
x.t("documentation","tib_b2b_home");
x.t("documentation","env_name");
x.t("documentation","tib_instream_home");
x.t("documentation","tib_translator_home");
x.t("translator","installed");
x.t("italic","font");
x.t("variable","command");
x.t("windows","start");
x.t("windows","name");
x.t("windows","services");
x.t("windows","systems");
x.t("displayed","command");
x.t("taken","tibco");
x.t("taken","taken");
x.t("instances","product");
x.t("keys","pressed");
x.t("value","c:\\tibco\\translator\\");
x.t("value","c:\\tibco");
x.t("value","tibco_home");
x.t("value","c:\\tibco\\bw\\plugins\\b2b");
x.t("value","tib_b2b_home");
x.t("value","c:\\tibco\\instream\\");
x.t("value","tib_instream_home");
x.t("value","tib_translator_home");
x.t("activematrix","businessworks");
x.t("additional","action");
x.t("b2b","installed");
x.t("title","example");
x.t("several","portlets");
x.t("importance","example");
x.t("specific","result");
x.t("convention","env_name");
x.t("process","bold");
x.t("services","created");
x.t("systems","default");
x.t("foo","process");
x.t("env_name","microsoft");
x.t("env_name","tibco_home");
x.t("output","displayed");
x.t("bold","code");
x.t("page","may");
x.t("mini-applications","run");
x.t("ctrl","key");
x.t("ctrl","note");
x.t("tip","icon");
x.t("corruption","certain");
x.t("information","provided");
x.t("information","special");
x.t("data","loss");
x.t("examples","filenames");
x.t("result","warning");
x.t("disable","italic");
x.t("tib_instream_home","default");
x.t("tib_instream_home","depends");
x.t("tib_instream_home","tib_translator_home");
x.t("pathnames","output");
x.t("portlets","mini-applications");
x.t("portlets","portlets");
x.t("note","icon");
x.t("typographical","conventions");
x.t("created","installer");
x.t("damaging","situation");
x.t("following","properties");
x.t("following","ways");
x.t("following","typographical");
x.t("used","manual");
x.t("used","following");
x.t("system","example");
x.t("run","portal");
x.t("separated","comma");
x.t("separated","plus");
x.t("special","interest");
x.t("general","typographical");
x.t("installation","environments");
x.t("installation","environment");
x.t("businessworks","plug-in");
x.t("businessworks","concepts");
x.t("warning","icon");
x.t("terms","example");
x.t("tib_translator_home","default");
x.t("tib_translator_home","depends");
x.t("tib_translator_home","tibco");
x.t("names","separated");
x.t("conventions","tibco");
x.t("conventions","convention");
x.t("conventions","typographical");
x.t("conventions","following");
x.t("conventions","used");
x.t("font","code");
x.t("font","identifies");
x.t("font","italic");
x.t("font","bold");
x.t("font","used");
x.t("concepts","introduce");
}
