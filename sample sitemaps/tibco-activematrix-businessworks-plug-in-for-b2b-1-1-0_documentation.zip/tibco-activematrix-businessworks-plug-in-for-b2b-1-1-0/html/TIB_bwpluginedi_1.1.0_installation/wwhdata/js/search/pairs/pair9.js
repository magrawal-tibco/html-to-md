function FileData_Pairs(x)
{
x.t("uninstallation","chapter");
x.t("uninstallation","tibco");
x.t("uninstall","product");
x.t("explains","install");
x.t("product","topics");
x.t("install","uninstall");
x.t("software","chapter");
x.t("chapter","explains");
x.t("chapter","installation");
x.t("tibco","software");
x.t("topics","installation");
x.t("installation","uninstallation");
}
