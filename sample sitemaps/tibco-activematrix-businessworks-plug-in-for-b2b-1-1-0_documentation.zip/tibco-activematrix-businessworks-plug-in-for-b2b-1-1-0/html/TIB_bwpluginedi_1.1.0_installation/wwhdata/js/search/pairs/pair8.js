function FileData_Pairs(x)
{
x.t("example","notify");
x.t("creation","configuration");
x.t("transactions","according");
x.t("delimited","positional");
x.t("easy","integration");
x.t("lists","required");
x.t("lists","(acls)");
x.t("scalable","extensible");
x.t("files","creation");
x.t("console","used");
x.t("inbound","outbound");
x.t("describes","disk");
x.t("refer","readme");
x.t("patches","software");
x.t("table","lists");
x.t("table","required");
x.t("integration","projects");
x.t("integration","platform");
x.t("installed","installing");
x.t("installed","install");
x.t("thorough","transaction");
x.t("business","rules");
x.t("required","patches");
x.t("required","optional");
x.t("ensures","compliance");
x.t("source-to-target","mapping");
x.t("translators","note");
x.t("performs","high-speed");
x.t("user","management");
x.t("foresight","instream");
x.t("foresight","translator");
x.t("platforms","refer");
x.t("platforms","product");
x.t("platforms","versions");
x.t("automate","transaction");
x.t("administrator","includes");
x.t("administrator","number");
x.t("administrator","(optional)");
x.t("deployment","monitoring");
x.t("introduction","installation");
x.t("time","deployed");
x.t("formats","without");
x.t("product","disk");
x.t("product","purpose");
x.t("exceeds","certain");
x.t("access","control");
x.t("certain","number");
x.t("start","stop");
x.t("engine","tibco");
x.t("includes","security");
x.t("includes","tibco");
x.t("includes","following");
x.t("instream","ensures");
x.t("instream","automate");
x.t("instream","install");
x.t("instream","tibco");
x.t("instream","(required)");
x.t("file","delimited");
x.t("file","supported");
x.t("file","disk");
x.t("file","memory");
x.t("security","server-based");
x.t("outbound","data");
x.t("standards","organizational");
x.t("installing","tibco");
x.t("enterprise","archive");
x.t("organization","validate");
x.t("validate","transactions");
x.t("according","industry");
x.t("limitation","traditional");
x.t("flat","file");
x.t("requirements","refer");
x.t("requirements","table");
x.t("requirements","supported");
x.t("requirements","software");
x.t("requirements","section");
x.t("requirements","tibco");
x.t("requirements","system");
x.t("requirements","installation");
x.t("products","refer");
x.t("products","product");
x.t("products","install");
x.t("libraries","used");
x.t("guidelines","specific");
x.t("readme","file");
x.t("stop","applications");
x.t("direct","source-to-target");
x.t("interim","storage");
x.t("allows","develop");
x.t("industry","standards");
x.t("organizational","guidelines");
x.t("develop","integration");
x.t("compliance","inbound");
x.t("plug-in","tibco");
x.t("plug-in","b2b");
x.t("resource","management");
x.t("flow","throughout");
x.t("designer","along");
x.t("supported","platforms");
x.t("supported","software");
x.t("deployed","applications");
x.t("disk","space");
x.t("disk","usage");
x.t("install","tibco");
x.t("server-based","projects");
x.t("uploading","enterprise");
x.t("validation","engine");
x.t("space","requirements");
x.t("connecting","roles");
x.t("domain","alerts");
x.t("number","processes");
x.t("number","tibco");
x.t("number","application");
x.t("control","lists");
x.t("notify","administrator");
x.t("design","time");
x.t("fastest","thorough");
x.t("software","requirements");
x.t("software","products");
x.t("software","chapter");
x.t("software","versions");
x.t("chapter","introduction");
x.t("extensible","easy");
x.t("processes","disk");
x.t("(acls)","includes");
x.t("section","describes");
x.t("xml","flat");
x.t("purpose","tibco");
x.t("positional","formats");
x.t("machines","running");
x.t("tibco","foresight");
x.t("tibco","administrator");
x.t("tibco","products");
x.t("tibco","designer");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("tibco","third-party");
x.t("tibco","runtime");
x.t("tibco","administration");
x.t("memory","requirements");
x.t("throughout","organization");
x.t("(required)","tibco");
x.t("projects","design");
x.t("projects","tibco");
x.t("translator","installed");
x.t("translator","performs");
x.t("translator","install");
x.t("translator","(required)");
x.t("(optional)","tibco");
x.t("alerts","created");
x.t("rules","note");
x.t("configuration","deployment");
x.t("activematrix","businessworks");
x.t("modules","user");
x.t("running","applications");
x.t("usage","exceeds");
x.t("b2b","tibco");
x.t("specific","business");
x.t("third-party","libraries");
x.t("authentication","roles");
x.t("along","number");
x.t("platform","allows");
x.t("optional","software");
x.t("optional","tibco");
x.t("monitoring","machines");
x.t("monitoring","applications");
x.t("archive","(ear)");
x.t("data","fastest");
x.t("high-speed","direct");
x.t("agent","includes");
x.t("agent","install");
x.t("agent","(required)");
x.t("traditional","translators");
x.t("runtime","resource");
x.t("runtime","agent");
x.t("application","management");
x.t("(ear)","files");
x.t("users","access");
x.t("users","connecting");
x.t("administration","domain");
x.t("transaction","flow");
x.t("transaction","validation");
x.t("note","install");
x.t("requiring","interim");
x.t("applications","console");
x.t("applications","tibco");
x.t("applications","runtime");
x.t("created","example");
x.t("mapping","edi");
x.t("system","memory");
x.t("used","start");
x.t("used","plug-in");
x.t("following","modules");
x.t("management","uploading");
x.t("management","authentication");
x.t("management","monitoring");
x.t("management","management");
x.t("(groups)","users");
x.t("storage","limitation");
x.t("installation","requirements");
x.t("businessworks","scalable");
x.t("businessworks","installed");
x.t("businessworks","plug-in");
x.t("businessworks","(required)");
x.t("edi","xml");
x.t("without","requiring");
x.t("versions","table");
x.t("versions","required");
x.t("roles","users");
x.t("roles","(groups)");
}
