function FileData_Pairs(x)
{
x.t("experience","tibco");
x.t("contact","tibco");
x.t("community","tibcommunity");
x.t("register","http://www.tibcommunity.com");
x.t("support","contract");
x.t("support","follows");
x.t("support","visit");
x.t("support","comments");
x.t("support","information");
x.t("please","contact");
x.t("product","versions");
x.t("access","collective");
x.t("access","tibco");
x.t("access","documentation");
x.t("access","variety");
x.t("getting","started");
x.t("contract","visit");
x.t("entry","site");
x.t("overview","tibco");
x.t("requires","username");
x.t("manual","software");
x.t("addresses","please");
x.t("follows","overview");
x.t("visit","site");
x.t("place","share");
x.t("preface","connecting");
x.t("destination","tibco");
x.t("collective","experience");
x.t("http://docs.tibco.com/tibcodoc","contact");
x.t("started","tibco");
x.t("problems","manual");
x.t("request","tibco");
x.t("supported","product");
x.t("experts","place");
x.t("connecting","tibco");
x.t("https://support.tibco.com","entry");
x.t("comments","problems");
x.t("software","addresses");
x.t("software","preface");
x.t("share","access");
x.t("maintenance","support");
x.t("customers","partners");
x.t("partners","resident");
x.t("forums","blogs");
x.t("tibco","community");
x.t("tibco","support");
x.t("tibco","software");
x.t("tibco","customers");
x.t("tibco","documentation");
x.t("tibco","resources");
x.t("resident","experts");
x.t("documentation","supported");
x.t("documentation","join");
x.t("blogs","access");
x.t("variety","resources");
x.t("username","request");
x.t("username","password");
x.t("already","valid");
x.t("valid","maintenance");
x.t("online","destination");
x.t("site","requires");
x.t("site","https://support.tibco.com");
x.t("site","http://www.tibco.com/services/support");
x.t("information","getting");
x.t("join","tibcommunity");
x.t("tibcommunity","access");
x.t("tibcommunity","online");
x.t("tibcommunity","tibcommunity");
x.t("tibcommunity","offers");
x.t("offers","forums");
x.t("password","username");
x.t("http://www.tibcommunity.com","access");
x.t("http://www.tibco.com/services/support","already");
x.t("versions","http://docs.tibco.com/tibcodoc");
x.t("resources","register");
x.t("resources","connecting");
x.t("resources","tibco");
x.t("resources","join");
}
