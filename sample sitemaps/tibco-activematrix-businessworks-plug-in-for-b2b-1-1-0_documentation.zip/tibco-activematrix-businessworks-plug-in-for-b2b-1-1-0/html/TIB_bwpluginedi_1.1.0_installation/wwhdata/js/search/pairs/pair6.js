function FileData_Pairs(x)
{
x.t("modes","requirements");
x.t("introduction","chapter");
x.t("introduction","tibco");
x.t("explains","installation");
x.t("overview","installation");
x.t("requirements","options");
x.t("requirements","tibco");
x.t("options","aware");
x.t("software","chapter");
x.t("chapter","introduction");
x.t("chapter","explains");
x.t("aware","starting");
x.t("starting","installation");
x.t("tibco","software");
x.t("topics","installation");
x.t("installation","modes");
x.t("installation","overview");
x.t("installation","requirements");
x.t("installation","topics");
}
