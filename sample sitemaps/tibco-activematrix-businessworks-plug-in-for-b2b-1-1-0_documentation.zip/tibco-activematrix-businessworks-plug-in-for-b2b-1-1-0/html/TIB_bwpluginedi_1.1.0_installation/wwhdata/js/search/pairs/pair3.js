function FileData_Pairs(x)
{
x.t("notes","list");
x.t("notes","read");
x.t("lists","known");
x.t("lists","documentation");
x.t("related","documentation");
x.t("instructions","site");
x.t("instructions","using");
x.t("foresight","instream");
x.t("foresight","translator");
x.t("administrator","tibco");
x.t("form","tibco");
x.t("product","tibco");
x.t("product","documentation");
x.t("new","changed");
x.t("document","contains");
x.t("instream","tibco");
x.t("list","new");
x.t("preparation","installation");
x.t("guide","read");
x.t("features","document");
x.t("products","tibco");
x.t("manual","instructions");
x.t("changed","features");
x.t("closed","issues");
x.t("useful","tibco");
x.t("useful","read");
x.t("find","useful");
x.t("preface","related");
x.t("plug-in","b2b");
x.t("designer","tibco");
x.t("documents","form");
x.t("hawk","tibco");
x.t("issues","closed");
x.t("issues","release");
x.t("software","preface");
x.t("may","find");
x.t("section","lists");
x.t("release","notes");
x.t("release","tibco");
x.t("tibco","foresight");
x.t("tibco","administrator");
x.t("tibco","product");
x.t("tibco","products");
x.t("tibco","designer");
x.t("tibco","hawk");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("tibco","runtime");
x.t("known","issues");
x.t("documentation","related");
x.t("documentation","may");
x.t("documentation","section");
x.t("documentation","tibco");
x.t("documentation","following");
x.t("documentation","resources");
x.t("translator","tibco");
x.t("activematrix","businessworks");
x.t("b2b","release");
x.t("b2b","documentation");
x.t("b2b","installation");
x.t("b2b","user\u2019s");
x.t("read","manual");
x.t("read","release");
x.t("read","documentation");
x.t("site","preparation");
x.t("agent","tibco");
x.t("runtime","agent");
x.t("following","documents");
x.t("following","tibco");
x.t("businessworks","plug-in");
x.t("businessworks","tibco");
x.t("installation","tibco");
x.t("installation","read");
x.t("using","product");
x.t("resources","may");
x.t("user\u2019s","guide");
x.t("contains","lists");
}
