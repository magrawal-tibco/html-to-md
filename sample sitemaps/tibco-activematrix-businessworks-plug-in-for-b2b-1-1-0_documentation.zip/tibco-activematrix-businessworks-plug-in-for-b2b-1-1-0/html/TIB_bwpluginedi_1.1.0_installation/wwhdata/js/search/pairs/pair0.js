function FileData_Pairs(x)
{
x.t("plug-in","b2b");
x.t("1.1","may");
x.t("2013","tibco");
x.t("software","release");
x.t("software","tibco");
x.t("may","2013");
x.t("release","1.1");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("activematrix","businessworks");
x.t("b2b","tibco");
x.t("b2b","installation");
x.t("businessworks","plug-in");
x.t("installation","software");
}
