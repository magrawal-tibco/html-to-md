function FileData_Pairs(x)
{
x.t("states","and/or");
x.t("provide","limited");
x.t("available","multiple");
x.t("improvements","and/or");
x.t("notes","read");
x.t("version","specific");
x.t("version","released");
x.t("files","2011-2013");
x.t("embeds","bundles");
x.t("bundles","tibco");
x.t("beans","(ejb)");
x.t("periodically","added");
x.t("u.s","international");
x.t("u.s","countries");
x.t("(ejb)","java");
x.t("user","license");
x.t("foresight","instream");
x.t("foresight","translator");
x.t("accompanies","software");
x.t("subject","u.s");
x.t("subject","terms");
x.t("download","installation");
x.t("platforms","specific");
x.t("program","(s)");
x.t("administrator","tibco");
x.t("provided","without");
x.t("errors","changes");
x.t("modified","and/or");
x.t("add-on","functionality");
x.t("time","contents");
x.t("time","readme");
x.t("editions","document");
x.t("bound","document");
x.t("international","laws");
x.t("form","without");
x.t("logos","trademarks");
x.t("multiple","operating");
x.t("however","operating");
x.t("implied","warranties");
x.t("implied","including");
x.t("fitness","particular");
x.t("product","(s)");
x.t("product","company");
x.t("property","respective");
x.t("new","editions");
x.t("contents","document");
x.t("licensed","tibco");
x.t("licensed","used");
x.t("document","subject");
x.t("document","provided");
x.t("document","time");
x.t("document","property");
x.t("document","may");
x.t("document","tibco");
x.t("document","include");
x.t("document","contains");
x.t("license","file");
x.t("license","agreement");
x.t("license","(s)");
x.t("acceptance","agreement");
x.t("instream","tibco");
x.t("indirectly","documentation");
x.t("found","either");
x.t("file","availability");
x.t("file","software");
x.t("file","(s)");
x.t("during","download");
x.t("enterprise","java");
x.t("enterprise","edition");
x.t("availability","software");
x.t("warranties","merchantability");
x.t("directly","indirectly");
x.t("functionality","provide");
x.t("functionality","licensed");
x.t("hereof","constitute");
x.t("trademarks","logos");
x.t("trademarks","trademarks");
x.t("trademarks","oracle");
x.t("trademarks","registered");
x.t("trademarks","tibco");
x.t("oracle","u.s");
x.t("readme","file");
x.t("part","document");
x.t("warranty","kind");
x.t("reproduced","form");
x.t("respective","owners");
x.t("accessed","tibco");
x.t("laws","treaties");
x.t("(j2ee)","java-based");
x.t("solely","enable");
x.t("clickwrap","end");
x.t("designer","tibco");
x.t("united","states");
x.t("separately","executed");
x.t("registered","trademarks");
x.t("non-infringement","document");
x.t("hawk","tibco");
x.t("2011-2013","tibco");
x.t("confidential","information");
x.t("written","authorization");
x.t("java-based","trademarks");
x.t("owners","mentioned");
x.t("software","version");
x.t("software","embeds");
x.t("software","licensed");
x.t("software","document");
x.t("software","license");
x.t("software","solely");
x.t("software","united");
x.t("software","confidential");
x.t("software","duplicated");
x.t("software","may");
x.t("software","important");
x.t("software","purpose");
x.t("software","tibco");
x.t("software","embedded");
x.t("software","including");
x.t("duplicated","license");
x.t("may","available");
x.t("may","improvements");
x.t("may","modified");
x.t("may","reproduced");
x.t("advantage","tibco");
x.t("particular","purpose");
x.t("changes","periodically");
x.t("changes","product");
x.t("changes","incorporated");
x.t("release","notes");
x.t("important","information");
x.t("purpose","non-infringement");
x.t("purpose","tibco");
x.t("marks","mentioned");
x.t("added","information");
x.t("enable","functionality");
x.t("executed","software");
x.t("end","user");
x.t("technical","inaccuracies");
x.t("located","license");
x.t("tibco","foresight");
x.t("tibco","administrator");
x.t("tibco","designer");
x.t("tibco","hawk");
x.t("tibco","software");
x.t("tibco","power");
x.t("tibco","activematrix");
x.t("tibco","two-second");
x.t("tibco","runtime");
x.t("authorization","tibco");
x.t("operating","systems");
x.t("operating","system");
x.t("embedded","bundled");
x.t("translator","either");
x.t("java","beans");
x.t("java","java");
x.t("java","platform");
x.t("identification","purposes");
x.t("kind","either");
x.t("documentation","accompanies");
x.t("displayed","during");
x.t("and/or","program");
x.t("and/or","changes");
x.t("and/or","qualified");
x.t("and/or","countries");
x.t("agreement","bound");
x.t("agreement","license");
x.t("agreement","found");
x.t("agreement","clickwrap");
x.t("agreement","displayed");
x.t("agreement","separate");
x.t("merchantability","fitness");
x.t("include","technical");
x.t("qualified","directly");
x.t("power","tibco");
x.t("activematrix","businessworks");
x.t("specific","software");
x.t("specific","operating");
x.t("express","implied");
x.t("two-second","advantage");
x.t("(s)","software");
x.t("(s)","located");
x.t("(s)","and/or");
x.t("(s)","described");
x.t("systems","however");
x.t("read","files");
x.t("separate","agreement");
x.t("treaties","part");
x.t("platform","document");
x.t("platform","enterprise");
x.t("purposes","software");
x.t("information","subject");
x.t("information","tibco");
x.t("information","two-second");
x.t("information","herein");
x.t("agent","tibco");
x.t("runtime","agent");
x.t("countries","product");
x.t("countries","enterprise");
x.t("described","document");
x.t("bundled","software");
x.t("bundled","tibco");
x.t("constitute","acceptance");
x.t("incorporated","new");
x.t("mentioned","document");
x.t("mentioned","identification");
x.t("typographical","errors");
x.t("edition","(j2ee)");
x.t("edition","java");
x.t("used","accessed");
x.t("either","separately");
x.t("either","registered");
x.t("either","express");
x.t("system","platforms");
x.t("system","platform");
x.t("installation","software");
x.t("businessworks","tibco");
x.t("terms","conditions");
x.t("company","names");
x.t("limited","add-on");
x.t("limited","implied");
x.t("limited","release");
x.t("without","warranty");
x.t("without","written");
x.t("names","marks");
x.t("released","time");
x.t("including","limited");
x.t("conditions","license");
x.t("conditions","hereof");
x.t("inaccuracies","typographical");
x.t("contains","confidential");
x.t("herein","changes");
}
