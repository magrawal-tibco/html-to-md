function FileData_Pairs(x)
{
x.t("modes","gui");
x.t("uninstallation","modes");
x.t("uninstallation","uninstallation");
x.t("uninstallation","type");
x.t("uninstallation","responding");
x.t("uninstallation","options");
x.t("uninstallation","tibco");
x.t("uninstallation","process");
x.t("uninstallation","following");
x.t("available","uninstallation");
x.t("pre-uninstall","summary");
x.t("console","mode");
x.t("console","window");
x.t("home","location");
x.t("uninstaller","removes");
x.t("summary","click");
x.t("mode","console");
x.t("mode","uninstall");
x.t("mode","complete");
x.t("mode","gui");
x.t("mode","using");
x.t("prompts","tibco");
x.t("uninstall","product");
x.t("uninstall","start");
x.t("uninstall","products");
x.t("uninstall","selection");
x.t("uninstall","select");
x.t("uninstall","button");
x.t("uninstall","click");
x.t("uninstall","process");
x.t("uninstall","universal");
x.t("type","page");
x.t("type","following");
x.t("exit","installer");
x.t("sections","describe");
x.t("shut","down");
x.t("down","running");
x.t("-console","complete");
x.t("-console","unix");
x.t("product","console");
x.t("product","uninstall");
x.t("product","gui");
x.t("removes","products");
x.t("start","uninstallation");
x.t("start","uninstall");
x.t("start","menu");
x.t("\\tools\\universal_installer","directory");
x.t("command","command");
x.t("command","window");
x.t("command","prompt");
x.t("list","click");
x.t("complete","uninstallation");
x.t("complete","following");
x.t("tibco_home","\\tools\\universal_installer");
x.t("tibco_home","click");
x.t("tibco_home","location");
x.t("menu","select");
x.t("responding","console");
x.t("installer","console");
x.t("installer","either");
x.t("check","checkboxes");
x.t("navigate","tibco_home");
x.t("navigate","universal");
x.t("checkboxes","products");
x.t("products","uninstall");
x.t("products","tibco_home");
x.t("products","selected");
x.t("products","tibco");
x.t("products","removed");
x.t("custom","uninstall");
x.t("methods","tibco_home");
x.t("welcome","page");
x.t("window","prompts");
x.t("window","navigate");
x.t("selection","page");
x.t("programs","tibco");
x.t("tibcouniversalinstaller","start");
x.t("selected","custom");
x.t("selected","directory");
x.t("review","pre-uninstall");
x.t("review","post-uninstall");
x.t("prompt","windows");
x.t("next","button");
x.t("select","uninstall");
x.t("select","tibco_home");
x.t("select","products");
x.t("select","programs");
x.t("select","following");
x.t("button","product");
x.t("button","start");
x.t("button","complete");
x.t("button","welcome");
x.t("button","selected");
x.t("button","review");
x.t("button","select");
x.t("button","click");
x.t("options","uninstallation");
x.t("gui","mode");
x.t("software","chapter");
x.t("chapter","installation");
x.t(".bin","-console");
x.t("unix","./tibcouniversalinstaller-");
x.t("directory","type");
x.t("directory","tibco");
x.t("directory","run");
x.t("steps","uninstall");
x.t("steps","shut");
x.t("tibco","home");
x.t("tibco","uninstall");
x.t("tibco","software");
x.t("tibco","applications");
x.t("tibco","installation");
x.t("click","uninstall");
x.t("click","next");
x.t("click","finish");
x.t("windows","tibcouniversalinstaller.exe");
x.t("tibcouniversalinstaller.exe","-console");
x.t("running","tibco");
x.t("drop-down","list");
x.t("./tibcouniversalinstaller-","platform_acronym");
x.t("process","available");
x.t("process","exit");
x.t("process","start");
x.t("process","complete");
x.t("process","review");
x.t("manager","page");
x.t("radio","button");
x.t("page","check");
x.t("page","custom");
x.t("page","select");
x.t("location","tibco");
x.t("location","drop-down");
x.t("location","radio");
x.t("typical","uninstall");
x.t("universal","uninstaller");
x.t("universal","installer");
x.t("post-uninstall","summary");
x.t("finish","button");
x.t("applications","navigate");
x.t("following","uninstallation");
x.t("following","sections");
x.t("following","command");
x.t("following","methods");
x.t("following","steps");
x.t("either","following");
x.t("run","tibcouniversalinstaller");
x.t("platform_acronym",".bin");
x.t("installation","uninstallation");
x.t("installation","manager");
x.t("using","command");
x.t("describe","uninstallation");
x.t("removed","radio");
x.t("removed","typical");
}
