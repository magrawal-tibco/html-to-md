function FileData_Pairs(x)
{
x.t("available","multiple");
x.t("version","specific");
x.t("version","released");
x.t("related","documentation");
x.t("platforms","specific");
x.t("please","readme");
x.t("uninstall","tibco");
x.t("time","please");
x.t("multiple","operating");
x.t("however","operating");
x.t("explains","install");
x.t("file","availability");
x.t("guide","explains");
x.t("availability","software");
x.t("readme","file");
x.t("preface","preface");
x.t("preface","software");
x.t("preface","tibco");
x.t("plug-in","b2b");
x.t("install","uninstall");
x.t("connecting","tibco");
x.t("software","version");
x.t("software","preface");
x.t("software","may");
x.t("may","available");
x.t("tibco","software");
x.t("tibco","activematrix");
x.t("tibco","resources");
x.t("operating","systems");
x.t("operating","system");
x.t("documentation","typographical");
x.t("activematrix","businessworks");
x.t("specific","software");
x.t("specific","operating");
x.t("b2b","topics");
x.t("systems","however");
x.t("platform","installation");
x.t("topics","related");
x.t("typographical","conventions");
x.t("system","platforms");
x.t("system","platform");
x.t("installation","guide");
x.t("businessworks","plug-in");
x.t("released","time");
x.t("conventions","connecting");
x.t("resources","tibco");
}
