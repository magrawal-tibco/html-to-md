function  WWHBookData_Files(P)
{
P.fA("TIBCO ActiveMatrix BusinessWorks\u2122 Plug-in for B2B","title.1.1.htm");
P.fA("Important Information","copyrigh.htm");
P.fA("Preface","preface.2.1.htm");
P.fA("Related Documentation","preface.2.2.htm");
P.fA("Typographical Conventions","preface.2.3.htm");
P.fA("Connecting with TIBCO Resources","preface.2.4.htm");
P.fA("Introduction","installation.3.1.htm");
P.fA("Installation Overview","installation.3.2.htm");
P.fA("Installation Requirements","installation.3.3.htm");
P.fA("Installation and Uninstallation","installation.3.4.htm");
P.fA("Installation","installation.3.5.htm");
P.fA("Uninstallation","installation.3.6.htm");
}
