function  WWHToWWHelpDirectory()
{
  return "";
}
