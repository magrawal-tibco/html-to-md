"""
03_convert.py — Step 3: Convert cached HTML to Markdown.

For each entry in the manifest:
  1. Parse cached HTML with BeautifulSoup
  2. Extract metadata from <html> attributes and coveo data in manifest
  3. Run 8 preprocessor transforms on the main content div
  4. Convert to Markdown with markdownify
  5. Prepend YAML frontmatter
  6. Write .md file to output/ (mirroring URL path)
  7. Copy images to output/ alongside the .md file

Usage:
  python scripts/03_convert.py --phase phase_01 [--config config/settings.yaml] [--dry-run]
"""

import argparse
import json
import re
import shutil
import sys
from collections import defaultdict
from pathlib import Path, PurePosixPath
from urllib.parse import urlparse

import warnings
import yaml
from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning
from markdownify import markdownify as md

warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).parent.parent))

from scripts.lib.preprocessor import run_all as run_preprocessor
from scripts.lib.reporter import Reporter
from scripts.lib.version_registry import record_converted_versions


def load_settings(config_path: str) -> dict:
    return yaml.safe_load(Path(config_path).read_text(encoding="utf-8"))


def load_manifest(phase: str, settings: dict) -> list[dict]:
    manifests_dir = Path(settings.get("manifests_dir", "manifests"))
    path = manifests_dir / f"manifest_{phase}.json"
    if not path.exists():
        raise FileNotFoundError(f"Manifest not found: {path}. Run Step 1 first.")
    return json.loads(path.read_text(encoding="utf-8"))


def load_dita_versions(phase: str, settings: dict) -> set[str]:
    """
    Return the set of version_sitemap URLs that are DITA format (file_dita or sdl_dita).
    Checks zip_registry first (most accurate post-extraction detection), then manifest entries.
    These versions are skipped by the MadCap converter and handled by scripts/dita/ instead.
    """
    manifests_dir = Path(settings.get("manifests_dir", "manifests"))
    dita_vs: set[str] = set()

    # Primary: zip_registry has format detected post-extraction
    reg_path = manifests_dir / f"zip_registry_{phase}.json"
    if reg_path.exists():
        registry = json.loads(reg_path.read_text(encoding="utf-8"))
        for vs, rec in registry.items():
            if rec.get("format") in ("file_dita", "sdl_dita"):
                dita_vs.add(vs)

    # Fallback: manifest entries with version_format=sdl_dita (set in Step 1)
    manifest_path = manifests_dir / f"manifest_{phase}.json"
    if manifest_path.exists():
        for entry in json.loads(manifest_path.read_text(encoding="utf-8")):
            if entry.get("version_format") == "sdl_dita":
                vs = entry.get("version_sitemap", "")
                if vs:
                    dita_vs.add(vs)

    return dita_vs


def url_to_cache_path(loc: str, cache_dir: Path) -> Path:
    path = urlparse(loc).path.lstrip("/")
    return cache_dir / path


_MONTH_NAMES = {
    "january": "01", "february": "02", "march": "03", "april": "04",
    "may": "05", "june": "06", "july": "07", "august": "08",
    "september": "09", "october": "10", "november": "11", "december": "12",
}
_MONTH_YEAR_RE = re.compile(
    r"(January|February|March|April|May|June|July|August|September|October|November|December)"
    r"\s+(\d{4})",
    re.IGNORECASE,
)


def _parse_release_date(text: str) -> str | None:
    m = _MONTH_YEAR_RE.search(text)
    if not m:
        return None
    return f"{m.group(2)}-{_MONTH_NAMES[m.group(1).lower()]}"


def _extract_release_date(entry: dict, cache_dir: Path) -> str | None:
    """Read release date from Home.htm (ga-date span) in the version HTML root."""
    alias_url = entry.get("alias_xml_url", "")
    if not alias_url:
        return None
    idx = alias_url.find("/Data/Alias.xml")
    if idx < 0:
        return None
    html_root_path = urlparse(alias_url[:idx]).path.lstrip("/")
    html_root_dir = cache_dir / html_root_path
    for rel in ("_templates/Home.htm", "Home.htm"):
        home_path = html_root_dir / rel
        if home_path.exists():
            try:
                soup = BeautifulSoup(home_path.read_bytes(), "lxml")
                span = soup.select_one("#ga-date span")
                if span:
                    rd = _parse_release_date(span.get_text(strip=True))
                    if rd:
                        return rd
            except Exception:
                pass
    return None


def _should_skip(url: str, skip_segments: list, skip_filenames: set,
                 html_extensions: set, skip_filename_patterns: list) -> bool:
    parsed   = urlparse(url)
    path     = parsed.path
    filename = PurePosixPath(path).name
    if filename in skip_filenames:
        return True
    if PurePosixPath(path).suffix.lower() not in html_extensions:
        return True
    for pat in skip_filename_patterns:
        if re.match(pat, filename, re.IGNORECASE):
            return True
    for seg in skip_segments:
        if seg in path:
            return True
    return False


def build_cache_driven_entries(manifest: list[dict], cache_dir: Path,
                               settings: dict) -> list[dict]:
    """
    Scan the cache directory for actual HTML files and build a conversion entry
    list driven by what exists on disk rather than what the sitemap listed.

    Uses manifest for per-URL metadata (toc_path lookup, alias_xml_url, etc.).
    Falls back to version-level metadata for files present in cache but absent
    from the manifest (common with ZIP-extracted content).

    DITA files are excluded naturally via skip_filename_patterns (GUID filenames).
    """
    base_url         = settings.get("base_url", "https://docs.tibco.com").rstrip("/")
    skip_segments    = settings.get("skip_path_segments", [])
    skip_filenames   = set(settings.get("skip_filenames", []))
    html_extensions  = set(settings.get("html_extensions", [".htm", ".html"]))
    skip_patterns    = settings.get("skip_filename_patterns", [])

    # Per-URL lookup for manifest metadata (only entries with a per-page URL)
    url_to_entry: dict[str, dict] = {e["url"]: e for e in manifest if "url" in e}

    # Group manifest entries by version to find each version's cache root.
    # Old format: keyed by version_sitemap. New format: keyed by version_url.
    version_groups: dict[str, list[dict]] = defaultdict(list)
    for e in manifest:
        vs = e.get("version_sitemap", "")
        if vs:
            version_groups[vs].append(e)
        elif "version_url" in e and "url" not in e:
            version_groups[e["version_url"]].append(e)

    # Determine the cache root directory for each version.
    # Strategy: take the path up to and including the version segment (X.Y.Z).
    _ver_re = re.compile(r"^\d+\.\d+")

    def _version_cache_root(entries: list[dict]) -> Path | None:
        url_path = urlparse(entries[0]["url"]).path.lstrip("/")
        parts    = PurePosixPath(url_path).parts
        root_parts: list[str] = []
        for part in parts:
            root_parts.append(part)
            if _ver_re.match(part):
                break
        if not root_parts:
            return None
        return cache_dir.joinpath(*root_parts)

    results: list[dict] = []
    seen_cache_paths: set[Path] = set()

    for vs, entries in version_groups.items():
        is_new_format = "version_url" in entries[0] and "url" not in entries[0]
        if is_new_format:
            pub_slug = entries[0].get("pub_slug", "")
            product_version = entries[0].get("product_version", "")
            if not pub_slug or not product_version:
                continue
            cache_root = cache_dir / "pub" / pub_slug / product_version / "doc" / "html"
        else:
            cache_root = _version_cache_root(entries)
        if cache_root is None or not cache_root.exists():
            continue

        # Version-level metadata (same for all files in this version)
        version_meta = {
            "product_name":    entries[0].get("product_name", ""),
            "product_version": entries[0].get("product_version", ""),
            "doc_name":        entries[0].get("doc_name", ""),
            "version_sitemap": "" if is_new_format else vs,
            "alias_xml_url":   entries[0].get("alias_xml_url", ""),
            "version_format":  entries[0].get("version_format", ""),
        }

        for html_path in sorted(cache_root.rglob("*")):
            if not html_path.is_file():
                continue
            if html_path.suffix.lower() not in html_extensions:
                continue
            if html_path in seen_cache_paths:
                continue
            seen_cache_paths.add(html_path)

            rel = html_path.relative_to(cache_dir).as_posix()
            url = f"{base_url}/{rel}"

            if _should_skip(url, skip_segments, skip_filenames, html_extensions, skip_patterns):
                continue

            if url in url_to_entry:
                entry = url_to_entry[url]
            else:
                output_path = str(html_path.relative_to(cache_dir).with_suffix(".md"))
                entry = {"url": url, "output_path": output_path, **version_meta}

            results.append(entry)

    return results


def extract_page_metadata(soup: BeautifulSoup, entry: dict) -> dict:
    """Extract per-page metadata from the <html> tag and manifest entry."""
    html_tag = soup.find("html")
    attrs = html_tag.attrs if html_tag else {}

    # Topic type from class attribute (concept, task, reference)
    classes = attrs.get("class", "")
    if isinstance(classes, list):
        classes = " ".join(classes)
    topic_type = ""
    for t in ("concept", "task", "reference"):
        if t in classes:
            topic_type = t
            break

    # TOC path — pipe-separated breadcrumb
    toc_path = attrs.get("data-mc-toc-path", "")
    if not toc_path:
        # EBX: breadcrumb in span.ebx_breadcrumbLabel, segments separated by " > "
        bc = soup.select_one("span.ebx_breadcrumbLabel")
        if bc:
            segments = [s.strip() for s in bc.get_text().split(">") if s.strip()]
            if segments and segments[0].lower() == "documentation":
                segments = segments[1:]
            toc_path = "|".join(segments)

    # Language
    lang = attrs.get("lang", attrs.get("xml:lang", "en-us"))

    # Title: prefer <title> tag, fallback to first h1 in content
    # EBX pages use "Product Documentation - <page title>" in <title>; use h1 instead.
    title_tag = soup.find("title")
    title = title_tag.get_text(strip=True) if title_tag else ""
    if entry.get("version_format") == "ebx" and " - " in title:
        h1 = soup.find("h1")
        if h1:
            title = h1.get_text(strip=True)

    product_name    = entry.get("product_name", "")
    product_version = entry.get("product_version", "")
    if product_version and product_name.endswith(product_version):
        product_name = product_name[: -len(product_version)].strip()

    return {
        "title":           title,
        "lang":            lang,
        "topic_type":      topic_type,
        "toc_path":        toc_path,
        "product_name":    product_name,
        "product_version": product_version,
        "doc_name":        entry.get("doc_name", ""),
        "source_url":      entry["url"],
    }


def build_frontmatter(meta: dict, extra: dict | None = None) -> str:
    """Render YAML frontmatter block."""
    data = {
        "title":           meta["title"],
        "source_url":      meta["source_url"],
        "lang":            meta["lang"],
        "topic_type":      meta["topic_type"],
        "toc_path":        meta["toc_path"],
        "product_name":    meta["product_name"],
        "product_version": meta["product_version"],
        "doc_name":        meta["doc_name"],
    }
    if extra:
        data.update(extra)
    # Remove empty fields
    data = {k: v for k, v in data.items() if v or v == 0}
    return "---\n" + yaml.dump(data, allow_unicode=True, default_flow_style=False) + "---\n\n"


def copy_images(html_content: bytes, page_url: str, cache_dir: Path,
                output_dir: Path, output_md_path: Path,
                skip_prefixes: list[str], dry_run: bool) -> int:
    """Copy images referenced in the HTML to the output directory."""
    from urllib.parse import urljoin
    soup = BeautifulSoup(html_content, "lxml")
    copied = 0
    output_page_dir = output_md_path.parent

    for img in soup.find_all("img", src=True):
        src = img["src"]
        if src.startswith("data:") or src.startswith("http"):
            continue
        if any(src.startswith(pfx) or f"/{pfx}" in src for pfx in skip_prefixes):
            continue
        # Resolve image URL and find its cached path
        abs_url = urljoin(page_url, src)
        cached  = url_to_cache_path(abs_url, cache_dir)
        if not cached.exists():
            continue
        # Place image relative to the output .md file
        img_path_in_url = urlparse(abs_url).path.lstrip("/")
        dest = output_dir / img_path_in_url
        if not dry_run:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(cached, dest)
        copied += 1
    return copied


def clean_markdown(text: str) -> str:
    """Post-process markdownify output to clean up common artefacts."""
    # Collapse 3+ consecutive blank lines to 2
    text = re.sub(r"\n{3,}", "\n\n", text)
    # Strip trailing whitespace on each line
    text = "\n".join(line.rstrip() for line in text.splitlines())
    # Fix inline markers running into adjacent text with no space.
    # markdownify strips trailing whitespace inside inline elements, so
    # <strong>Enter </strong>to  →  **Enter**to  (space lost).
    # Lookbehind (?<=\S) targets only *closing* markers (preceded by content),
    # so opening markers like "**word" are not affected.
    text = re.sub(r'(?<=\S)\*\*(?=[a-zA-Z0-9])', '** ', text)
    text = re.sub(r'(?<=\S)`(?=[a-zA-Z0-9])', '` ', text)
    return text.strip() + "\n"


_MC_STYLE_RE = re.compile(r"mc-table-style\s*:[^;\"]+;?", re.IGNORECASE)


def _clean_table_html(table) -> str:
    """Strip MadCap-specific attributes from a table before HTML passthrough."""
    for el in table.find_all(True):
        # Remove MadCap class names (keep element, remove noisy classes)
        if el.get("class"):
            del el["class"]
        # Strip mc-table-style from inline style; remove style if empty after
        if el.get("style"):
            cleaned = _MC_STYLE_RE.sub("", el["style"]).strip().strip(";").strip()
            if cleaned:
                el["style"] = cleaned
            else:
                del el["style"]
        # Remove cellspacing and other layout-only attributes
        for attr in ("cellspacing", "cellpadding", "border"):
            if el.get(attr) is not None:
                del el[attr]
        # Remove <col> elements — carry no semantic content
        if el.name == "col":
            el.decompose()
    return str(table)


def extract_passthrough_tables(content) -> dict[str, str]:
    """
    Find all Tier 3 tables (marked data-converter-passthrough="true"),
    replace each with a unique placeholder, and return {placeholder: raw_html}.
    Called before markdownify so the complex tables are not converted to GFM.
    """
    tables = {}
    for i, table in enumerate(
        content.find_all("table", attrs={"data-converter-passthrough": "true"})
    ):
        placeholder = f"%%PASSTHROUGH-TABLE-{i}%%"
        del table["data-converter-passthrough"]  # remove internal marker
        tables[placeholder] = _clean_table_html(table)
        # Replace the table in the tree with a plain paragraph holding the token
        p = BeautifulSoup(f"<p>{placeholder}</p>", "lxml").find("p")
        table.replace_with(p)
    return tables


def restore_passthrough_tables(md_text: str, tables: dict[str, str]) -> str:
    """Substitute placeholder tokens back with raw HTML table strings."""
    for placeholder, html in tables.items():
        md_text = md_text.replace(placeholder, f"\n{html}\n")
    return md_text


def convert_entry(
    entry: dict,
    settings: dict,
    cache_dir: Path,
    output_dir: Path,
    reporter: Reporter,
    dry_run: bool,
    force_rerun: bool = False,
    cache_path: Path | None = None,
) -> bool:
    """Convert one manifest entry from HTML to Markdown. Returns True on success."""
    url        = entry["url"]
    cache_path = cache_path or url_to_cache_path(url, cache_dir)
    out_path   = output_dir / entry["output_path"]

    if not cache_path.exists():
        reporter.fail(url, "cached HTML not found — run Step 2 first")
        return False

    if out_path.exists() and not dry_run and not force_rerun:
        reporter.count("pages_already_done")
        return True

    try:
        html_bytes = cache_path.read_bytes()
        soup = BeautifulSoup(html_bytes, "lxml")

        # Extract metadata
        meta = extract_page_metadata(soup, entry)

        # Find main content — try selectors in order from settings
        content = None
        content_selectors = settings.get("content_selectors", ["div[role='main']#mc-main-content"])
        selector_used = None
        for selector in content_selectors:
            content = soup.select_one(selector)
            if content:
                selector_used = selector
                break

        if content is None:
            reporter.skip(url, "no MadCap content div — non-topic HTML skipped")
            reporter.count("missing_content_div")
            return True

        reporter.count(f"selector:{selector_used}")

        # Update title from first h1 if <title> tag was empty
        if not meta["title"]:
            h1 = content.find("h1")
            meta["title"] = h1.get_text(strip=True) if h1 else Path(url).stem

        # Run preprocessor transforms
        page_url_path = urlparse(url).path
        chrome_selectors = list(settings.get("chrome_selectors", []))
        if entry.get("version_format") == "ebx":
            chrome_selectors += settings.get("ebx_chrome_selectors", [])
        block_tags = set(settings.get("tables", {}).get("passthrough_block_tags", []))
        transform_stats = run_preprocessor(content, chrome_selectors, page_url_path, block_tags)
        for k, v in transform_stats.items():
            reporter.count(f"transform_{k}", v)

        # Extract Tier 3 passthrough tables before markdownify runs
        passthrough_tables = extract_passthrough_tables(content)
        if passthrough_tables:
            reporter.count("transform_tier3_passthrough", len(passthrough_tables))

        # Convert to Markdown
        md_body = md(
            str(content),
            heading_style="ATX",
            bullets="-",
            newline_style="backslash",
        )
        md_body = clean_markdown(md_body)

        # Restore passthrough tables as raw HTML blocks
        if passthrough_tables:
            md_body = restore_passthrough_tables(md_body, passthrough_tables)
            md_body = clean_markdown(md_body)

        # Build final file content
        extra: dict = {}
        rd = entry.get("release_date")
        if rd:
            extra["release_date"] = rd
        frontmatter = build_frontmatter(meta, extra or None)
        final_content = frontmatter + md_body

        if not dry_run:
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(final_content, encoding="utf-8")

        # Copy images
        skip_prefixes = settings.get("image_skip_prefixes", [])
        images_copied = copy_images(
            html_bytes, url, cache_dir, output_dir, out_path, skip_prefixes, dry_run
        )
        reporter.count("images_copied", images_copied)
        reporter.count("pages_converted")
        return True

    except Exception as exc:
        reporter.fail(url, f"{type(exc).__name__}: {exc}")
        return False


def main():
    parser = argparse.ArgumentParser(description="Step 3: Convert HTML to Markdown")
    parser.add_argument("--phase",        required=True)
    parser.add_argument("--config",       default="config/settings.yaml")
    parser.add_argument("--dry-run",      action="store_true")
    parser.add_argument("--force-rerun",  action="store_true",
                        help="Re-convert pages that are already done")
    parser.add_argument("--scan-cache",   action="store_true",
                        help="Drive conversion from cached HTML files on disk rather than "
                             "sitemap manifest — eliminates 'cached HTML not found' errors "
                             "when ZIPs contain files not listed in the sitemap")
    args = parser.parse_args()

    settings   = load_settings(args.config)
    manifest   = load_manifest(args.phase, settings)
    cache_dir  = Path(settings.get("cache_dir", "cache"))
    output_dir = Path(settings.get("output_dir", "output"))

    from datetime import datetime
    logs_dir = Path(settings.get("logs_dir", "logs"))
    run_dir  = logs_dir / args.phase / datetime.now().strftime("%Y%m%d-%H%M%S")
    reporter = Reporter(run_dir, "03_convert", dry_run=args.dry_run)

    force_rerun = args.force_rerun

    # DITA versions (file_dita, sdl_dita) are handled by scripts/dita/ — skip here
    dita_versions = load_dita_versions(args.phase, settings)
    if dita_versions:
        reporter.info(f"Skipping {len(dita_versions)} DITA version(s) — use scripts/dita/run.py for those")

    if args.scan_cache:
        work_entries = build_cache_driven_entries(manifest, cache_dir, settings)
        reporter.info(
            f"=== Step 3: Convert | phase={args.phase} mode=scan-cache "
            f"dry_run={args.dry_run} force_rerun={force_rerun} ==="
        )
        reporter.info(f"Manifest: {len(manifest)} entries | Cache scan: {len(work_entries)} HTML files found")
    else:
        zip_only = [e for e in manifest if "url" not in e]
        work_entries = [
            e for e in manifest
            if "url" in e and e.get("version_sitemap", "") not in dita_versions
        ]
        reporter.info(
            f"=== Step 3: Convert | phase={args.phase} mode=manifest "
            f"dry_run={args.dry_run} force_rerun={force_rerun} ==="
        )
        reporter.info(f"Manifest: {len(manifest)} entries")
        if zip_only:
            reporter.info(
                f"{len(zip_only)} version-level entry(ies) have no page URL "
                f"— run --scan-cache after ZIP extraction (step 2a)"
            )

    # Pre-compute release_date per version from Home.htm (ga-date span)
    version_release_dates: dict[str, str | None] = {}
    for entry in work_entries:
        vs = entry.get("version_sitemap", "")
        if vs and vs not in version_release_dates:
            version_release_dates[vs] = _extract_release_date(entry, cache_dir)
    found_dates = sum(1 for v in version_release_dates.values() if v)
    reporter.info(f"Release dates found in Home.htm: {found_dates}/{len(version_release_dates)} versions")
    for entry in work_entries:
        vs = entry.get("version_sitemap", "")
        rd = version_release_dates.get(vs)
        if rd:
            entry["release_date"] = rd

    # Track conversion errors per version so only fully-successful versions are registered
    version_errors: dict[str, int] = {}
    for entry in work_entries:
        vs = entry.get("version_sitemap", "")
        if vs and vs not in version_errors:
            version_errors[vs] = 0

    for entry in tqdm(work_entries, desc="Converting"):
        vs = entry.get("version_sitemap", "")
        # In manifest mode, DITA skip is applied here (already filtered in scan-cache mode)
        if not args.scan_cache and vs in dita_versions:
            reporter.count("pages_dita_skipped")
            continue
        ok = convert_entry(entry, settings, cache_dir, output_dir, reporter, args.dry_run, force_rerun)
        if not ok:
            if vs:
                version_errors[vs] += 1

    # Write successfully completed versions to the registry
    manifests_dir = Path(settings.get("manifests_dir", "manifests"))
    newly_registered = record_converted_versions(
        manifest, version_errors, args.phase, manifests_dir, dry_run=args.dry_run
    )
    if newly_registered:
        reporter.info(f"Version registry updated: {len(newly_registered)} version(s) marked as converted")
        for vs in newly_registered:
            reporter.info(f"  + {vs}")
    else:
        reporter.info("Version registry: no new versions registered (errors present or dry run)")

    # Copy path segments (e.g. Java_API/, java/) as-is from cache to output.
    # Scoped to the current phase's versions via the zip_registry.
    copy_segments = {s.strip("/") for s in settings.get("copy_path_segments", [])}
    if copy_segments and not args.dry_run:
        reg_path = manifests_dir / f"zip_registry_{args.phase}.json"
        zip_registry: dict = json.loads(reg_path.read_text(encoding="utf-8")) if reg_path.exists() else {}
        for reg_entry in zip_registry.values():
            html_root = reg_entry.get("html_root", "").rstrip("/")
            version_fmt = reg_entry.get("format", "")
            search_root = cache_dir / html_root
            # EBX: html_root is doc/html/ which does not exist in addon ZIPs.
            # Fall back to doc/ (one level up) so we only copy doc/<addon>/Java_API/
            # and never reach standalone <addon>/Java_API/ at the version root.
            if not search_root.exists():
                parent = search_root.parent
                if parent.exists():
                    search_root = parent
                elif version_fmt == "ebx":
                    continue  # cannot determine search root for EBX — skip
                else:
                    search_root = search_root.parent
            if not search_root.exists():
                continue
            for src in search_root.rglob("*"):
                if src.is_dir() and src.name in copy_segments:
                    rel = src.relative_to(cache_dir)
                    dst = output_dir / rel
                    if not dst.exists() or force_rerun:
                        shutil.copytree(src, dst, dirs_exist_ok=True)
                        reporter.info(f"Copied {rel} → output/{rel}")

    report = reporter.finish()
    return 0 if report["error_count"] == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
